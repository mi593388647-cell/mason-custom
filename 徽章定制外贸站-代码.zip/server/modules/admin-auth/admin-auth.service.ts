import { Injectable, Inject, Logger, UnauthorizedException } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { adminUsers } from '@server/database/schema-manual';
import { eq } from 'drizzle-orm';
import type { AdminLoginRequest, AdminLoginResponse } from '@shared/api.interface';
import { generateAdminToken, verifyPassword } from './admin-token.util';

@Injectable()
export class AdminAuthService {
  private readonly logger = new Logger(AdminAuthService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  async login(dto: AdminLoginRequest): Promise<AdminLoginResponse> {
    try {
      const rows = await this.db
        .select()
        .from(adminUsers)
        .where(eq(adminUsers.username, dto.username))
        .limit(1);

      if (rows.length === 0) {
        this.logger.warn(`Login failed: user ${dto.username} not found`);
        throw new UnauthorizedException('Invalid username or password');
      }

      const user = rows[0];

      const passwordValid = verifyPassword(dto.password, user.passwordHash);
      const legacyValid = dto.password === user.passwordHash;
      if (!passwordValid && !legacyValid) {
        this.logger.warn(`Login failed: wrong password for ${dto.username}`);
        throw new UnauthorizedException('Invalid username or password');
      }

      const token = generateAdminToken(user.username);
      this.logger.log(`Admin login successful: ${user.username}`);

      return {
        success: true,
        token,
        username: user.username,
      };
    } catch (error) {
      if (error instanceof UnauthorizedException) {
        throw error;
      }
      this.logger.error('Login error', JSON.stringify(error));
      throw error;
    }
  }
}
