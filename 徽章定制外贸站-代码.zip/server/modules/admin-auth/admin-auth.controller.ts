import { Controller, Post, Body } from '@nestjs/common';
import { AdminAuthService } from './admin-auth.service';
import type { AdminLoginRequest, AdminLoginResponse } from '@shared/api.interface';

@Controller('api/admin-auth')
export class AdminAuthController {
  constructor(private readonly adminAuthService: AdminAuthService) {}

  @Post('login')
  async login(@Body() dto: AdminLoginRequest): Promise<AdminLoginResponse> {
    return this.adminAuthService.login(dto);
  }
}
