import { createHmac, randomBytes } from 'crypto';

const TOKEN_SECRET =
  process.env.ADMIN_TOKEN_SECRET || 'mason-custom-admin-secret-key-2024';
const TOKEN_TTL_MS = 24 * 60 * 60 * 1000;

export function generateAdminToken(username: string): string {
  const timestamp = Date.now().toString();
  const payload = `${username}:${timestamp}`;
  const signature = createHmac('sha256', TOKEN_SECRET)
    .update(payload)
    .digest('hex');
  const token = Buffer.from(`${payload}:${signature}`).toString('base64url');
  return token;
}

export function verifyAdminToken(token: string): {
  valid: boolean;
  username: string | null;
} {
  try {
    const decoded = Buffer.from(token, 'base64url').toString('utf-8');
    const parts = decoded.split(':');
    if (parts.length < 3) return { valid: false, username: null };

    const signature = parts[parts.length - 1];
    const username = parts.slice(0, parts.length - 2).join(':');
    const timestamp = parseInt(parts[parts.length - 2], 10);

    const payload = `${username}:${timestamp}`;
    const expectedSignature = createHmac('sha256', TOKEN_SECRET)
      .update(payload)
      .digest('hex');

    if (signature !== expectedSignature) {
      return { valid: false, username: null };
    }

    if (Date.now() - timestamp > TOKEN_TTL_MS) {
      return { valid: false, username: null };
    }

    return { valid: true, username };
  } catch {
    return { valid: false, username: null };
  }
}

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex');
  const hash = createHmac('sha256', salt).update(password).digest('hex');
  return `sha256$${salt}$${hash}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  try {
    const parts = storedHash.split('$');
    if (parts.length !== 3) return false;

    const [algorithm, salt, hash] = parts;
    if (algorithm !== 'sha256') return false;

    const computed = createHmac('sha256', salt).update(password).digest('hex');
    return computed === hash;
  } catch {
    return false;
  }
}
