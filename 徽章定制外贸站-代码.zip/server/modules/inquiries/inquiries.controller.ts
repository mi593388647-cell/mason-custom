import {
  Controller,
  Post,
  Get,
  Patch,
  Body,
  Param,
  Query,
  UseGuards,
} from '@nestjs/common';
import { InquiriesService } from './inquiries.service';
import type {
  Inquiry,
  InquiryCreateRequest,
  InquiryListResponse,
  InquiryUpdateStatusRequest,
} from '@shared/api.interface';
import { AdminAuthGuard } from '../admin-auth/admin-auth.guard';

@Controller('api/inquiries')
export class InquiriesController {
  constructor(private readonly inquiriesService: InquiriesService) {}

  @Post()
  async create(@Body() dto: InquiryCreateRequest): Promise<{ id: string }> {
    return this.inquiriesService.create(dto);
  }

  @UseGuards(AdminAuthGuard)
  @Get()
  async findAll(@Query('status') status?: string): Promise<InquiryListResponse> {
    return this.inquiriesService.findAll(status);
  }

  @UseGuards(AdminAuthGuard)
  @Get(':id')
  async findOne(@Param('id') id: string): Promise<Inquiry> {
    return this.inquiriesService.findOne(id);
  }

  @UseGuards(AdminAuthGuard)
  @Patch(':id/status')
  async updateStatus(
    @Param('id') id: string,
    @Body() dto: InquiryUpdateStatusRequest,
  ): Promise<{ id: string }> {
    return this.inquiriesService.updateStatus(id, dto);
  }
}
