import { Injectable, Inject, Logger, NotFoundException } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { inquiries } from '@server/database/schema-manual';
import { eq, desc, count, and, SQL } from 'drizzle-orm';
import type {
  Inquiry,
  InquiryCreateRequest,
  InquiryListResponse,
  InquiryUpdateStatusRequest,
} from '@shared/api.interface';

@Injectable()
export class InquiriesService {
  private readonly logger = new Logger(InquiriesService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  async create(dto: InquiryCreateRequest): Promise<{ id: string }> {
    try {
      const result = await this.db
        .insert(inquiries)
        .values({
          name: dto.name,
          email: dto.email,
          company: dto.company,
          country: dto.country,
          productType: dto.productType,
          quantity: dto.quantity ?? null,
          designFileUrl: dto.designFileUrl ?? null,
          designFileName: dto.designFileName ?? null,
          message: dto.message,
          status: 'pending',
        })
        .returning({ id: inquiries.id });

      this.logger.log(`Inquiry submitted: ${result[0].id}`);
      return { id: result[0].id };
    } catch (error) {
      this.logger.error('Failed to create inquiry', JSON.stringify(error));
      throw error;
    }
  }

  async findAll(status?: string): Promise<InquiryListResponse> {
    try {
      const conditions: SQL[] = [];
      if (status && (status === 'pending' || status === 'processed')) {
        conditions.push(eq(inquiries.status, status));
      }

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const baseQuery = whereClause
        ? this.db.select().from(inquiries).where(whereClause)
        : this.db.select().from(inquiries);

      const rows = await baseQuery.orderBy(desc(inquiries.createdAt));

      const countResult = whereClause
        ? await this.db.select({ count: count() }).from(inquiries).where(whereClause)
        : await this.db.select({ count: count() }).from(inquiries);

      const total = Number(countResult[0].count);

      const items: Inquiry[] = rows.map((row) => ({
        id: row.id,
        name: row.name,
        email: row.email,
        company: row.company,
        country: row.country,
        productType: row.productType,
        quantity: row.quantity,
        designFileUrl: row.designFileUrl,
        designFileName: row.designFileName,
        message: row.message,
        status: row.status as 'pending' | 'processed',
        createdAt: row.createdAt.toISOString(),
        updatedAt: row.updatedAt.toISOString(),
      }));

      return { items, total };
    } catch (error) {
      this.logger.error('Failed to fetch inquiries', JSON.stringify(error));
      throw error;
    }
  }

  async findOne(id: string): Promise<Inquiry> {
    try {
      const rows = await this.db.select().from(inquiries).where(eq(inquiries.id, id));

      if (rows.length === 0) {
        throw new NotFoundException('Inquiry not found');
      }

      const row = rows[0];
      return {
        id: row.id,
        name: row.name,
        email: row.email,
        company: row.company,
        country: row.country,
        productType: row.productType,
        quantity: row.quantity,
        designFileUrl: row.designFileUrl,
        designFileName: row.designFileName,
        message: row.message,
        status: row.status as 'pending' | 'processed',
        createdAt: row.createdAt.toISOString(),
        updatedAt: row.updatedAt.toISOString(),
      };
    } catch (error) {
      this.logger.error(`Failed to fetch inquiry ${id}`, JSON.stringify(error));
      throw error;
    }
  }

  async updateStatus(id: string, dto: InquiryUpdateStatusRequest): Promise<{ id: string }> {
    try {
      const updated = await this.db
        .update(inquiries)
        .set({
          status: dto.status,
          updatedAt: new Date(),
        })
        .where(eq(inquiries.id, id))
        .returning({ id: inquiries.id });

      if (updated.length === 0) {
        throw new NotFoundException('Inquiry not found');
      }

      this.logger.log(`Inquiry ${id} status updated to ${dto.status}`);
      return { id: updated[0].id };
    } catch (error) {
      this.logger.error(`Failed to update inquiry status ${id}`, JSON.stringify(error));
      throw error;
    }
  }
}
