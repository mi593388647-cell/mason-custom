import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ProductsService } from './products.service';
import type {
  Product,
  ProductListResponse,
  ProductCreateRequest,
  ProductUpdateRequest,
} from '@shared/api.interface';
import { AdminAuthGuard } from '../admin-auth/admin-auth.guard';

@Controller('api/products')
export class ProductsController {
  constructor(private readonly productsService: ProductsService) {}

  @UseGuards(AdminAuthGuard)
  @Get('admin/list')
  async findAllAdmin(): Promise<ProductListResponse> {
    return this.productsService.findAllAdmin();
  }

  @Get()
  async findPublic(@Query('category') category?: string): Promise<ProductListResponse> {
    return this.productsService.findPublic(category);
  }

  @Get(':slug')
  async findBySlug(@Param('slug') slug: string): Promise<Product> {
    return this.productsService.findBySlug(slug);
  }

  @UseGuards(AdminAuthGuard)
  @Post()
  async create(@Body() dto: ProductCreateRequest): Promise<Product> {
    return this.productsService.create(dto);
  }

  @UseGuards(AdminAuthGuard)
  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() dto: ProductUpdateRequest,
  ): Promise<Product> {
    return this.productsService.update(id, dto);
  }

  @UseGuards(AdminAuthGuard)
  @Delete(':id')
  async remove(@Param('id') id: string): Promise<{ success: boolean }> {
    await this.productsService.remove(id);
    return { success: true };
  }
}
