import {
  Inject,
  Injectable,
  Logger,
  NotFoundException,
  ConflictException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, count, asc } from 'drizzle-orm';
import { products } from '@server/database/schema-manual';
import type {
  Product,
  ProductCreateRequest,
  ProductUpdateRequest,
  ProductListResponse,
} from '@shared/api.interface';

@Injectable()
export class ProductsService {
  private readonly logger = new Logger(ProductsService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  private mapToProduct(row: typeof products.$inferSelect): Product {
    return {
      id: row.id,
      name: row.name,
      slug: row.slug,
      category: row.category,
      description: row.description,
      specifications: row.specifications as Product['specifications'],
      moq: row.moq,
      priceRange: row.priceRange,
      imageUrls: row.imageUrls as string[],
      sortOrder: row.sortOrder,
      isActive: row.isActive,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    };
  }

  async findPublic(category?: string): Promise<ProductListResponse> {
    try {
      const conditions = [eq(products.isActive, true)];
      if (category) {
        conditions.push(eq(products.category, category));
      }
      const whereClause = and(...conditions);

      const [rows, countResult] = await Promise.all([
        this.db.select().from(products).where(whereClause).orderBy(asc(products.sortOrder)),
        this.db.select({ count: count() }).from(products).where(whereClause),
      ]);

      const items: Product[] = rows.map((row: typeof products.$inferSelect) =>
        this.mapToProduct(row),
      );
      const total: number = Number(countResult[0]?.count ?? 0);

      return { items, total };
    } catch (error) {
      this.logger.error('获取公开产品列表失败', JSON.stringify(error));
      throw error;
    }
  }

  async findBySlug(slug: string): Promise<Product> {
    try {
      const rows = await this.db
        .select()
        .from(products)
        .where(and(eq(products.slug, slug), eq(products.isActive, true)))
        .limit(1);

      if (rows.length === 0) {
        throw new NotFoundException('产品不存在');
      }

      return this.mapToProduct(rows[0]);
    } catch (error) {
      this.logger.error(`根据 slug 获取产品失败: ${slug}`, JSON.stringify(error));
      throw error;
    }
  }

  async findAllAdmin(): Promise<ProductListResponse> {
    try {
      const [rows, countResult] = await Promise.all([
        this.db.select().from(products).orderBy(asc(products.sortOrder)),
        this.db.select({ count: count() }).from(products),
      ]);

      const items: Product[] = rows.map((row: typeof products.$inferSelect) =>
        this.mapToProduct(row),
      );
      const total: number = Number(countResult[0]?.count ?? 0);

      return { items, total };
    } catch (error) {
      this.logger.error('获取管理端产品列表失败', JSON.stringify(error));
      throw error;
    }
  }

  async create(dto: ProductCreateRequest): Promise<Product> {
    try {
      const rows = await this.db
        .insert(products)
        .values({
          name: dto.name,
          slug: dto.slug,
          category: dto.category,
          description: dto.description,
          specifications: dto.specifications,
          moq: dto.moq,
          priceRange: dto.priceRange,
          imageUrls: dto.imageUrls,
          sortOrder: dto.sortOrder,
          isActive: dto.isActive,
        })
        .returning();

      return this.mapToProduct(rows[0]);
    } catch (error) {
      this.logger.error('创建产品失败', JSON.stringify(error));
      const code = this.extractPostgresErrorCode(error);
      if (code === '23505') {
        throw new ConflictException('产品 slug 已存在');
      }
      throw error;
    }
  }

  async update(id: string, dto: ProductUpdateRequest): Promise<Product> {
    try {
      const patch: Partial<typeof products.$inferInsert> = {};
      if (dto.name !== undefined) patch.name = dto.name;
      if (dto.slug !== undefined) patch.slug = dto.slug;
      if (dto.category !== undefined) patch.category = dto.category;
      if (dto.description !== undefined) patch.description = dto.description;
      if (dto.specifications !== undefined) patch.specifications = dto.specifications;
      if (dto.moq !== undefined) patch.moq = dto.moq;
      if (dto.priceRange !== undefined) patch.priceRange = dto.priceRange;
      if (dto.imageUrls !== undefined) patch.imageUrls = dto.imageUrls;
      if (dto.sortOrder !== undefined) patch.sortOrder = dto.sortOrder;
      if (dto.isActive !== undefined) patch.isActive = dto.isActive;

      if (Object.keys(patch).length === 0) {
        throw new NotFoundException('未提供可更新字段');
      }

      patch.updatedAt = new Date();

      const rows = await this.db
        .update(products)
        .set(patch)
        .where(eq(products.id, id))
        .returning();

      if (rows.length === 0) {
        throw new NotFoundException('产品不存在');
      }

      return this.mapToProduct(rows[0]);
    } catch (error) {
      this.logger.error(`更新产品失败: ${id}`, JSON.stringify(error));
      const code = this.extractPostgresErrorCode(error);
      if (code === '23505') {
        throw new ConflictException('产品 slug 已存在');
      }
      throw error;
    }
  }

  async remove(id: string): Promise<void> {
    try {
      const rows = await this.db
        .delete(products)
        .where(eq(products.id, id))
        .returning({ id: products.id });

      if (rows.length === 0) {
        throw new NotFoundException('产品不存在');
      }
    } catch (error) {
      this.logger.error(`删除产品失败: ${id}`, JSON.stringify(error));
      throw error;
    }
  }

  private extractPostgresErrorCode(error: unknown): string | undefined {
    let current: unknown = error;
    for (let depth = 0; depth < 4 && current && typeof current === 'object'; depth += 1) {
      const { code, cause } = current as { code?: unknown; cause?: unknown };
      if (typeof code === 'string') return code;
      current = cause;
    }
    return undefined;
  }
}
