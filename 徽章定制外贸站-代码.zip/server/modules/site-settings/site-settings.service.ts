import { Injectable, Inject, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { siteSettings } from '@server/database/schema-manual';
import { eq } from 'drizzle-orm';
import type { SiteSettings, SiteSettingsUpdateRequest, FaqItem } from '@shared/api.interface';

@Injectable()
export class SiteSettingsService {
  private readonly logger = new Logger(SiteSettingsService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  async get(): Promise<SiteSettings> {
    try {
      const rows = await this.db.select().from(siteSettings).limit(1);

      if (rows.length === 0) {
        throw new NotFoundException('Site settings not found');
      }

      const row = rows[0];
      return {
        id: row.id,
        companyName: row.companyName,
        tagline: row.tagline,
        aboutText: row.aboutText,
        contactEmail: row.contactEmail,
        contactPhone: row.contactPhone,
        address: row.address,
        heroTitle: row.heroTitle,
        heroSubtitle: row.heroSubtitle,
        socialLinks: row.socialLinks as Record<string, string>,
        faqItems: row.faqItems as FaqItem[],
        updatedAt: row.updatedAt.toISOString(),
      };
    } catch (error) {
      this.logger.error('Failed to fetch site settings', JSON.stringify(error));
      throw error;
    }
  }

  async update(dto: SiteSettingsUpdateRequest): Promise<SiteSettings> {
    try {
      const patch: Partial<typeof siteSettings.$inferInsert> = {};

      if (dto.companyName !== undefined) patch.companyName = dto.companyName;
      if (dto.tagline !== undefined) patch.tagline = dto.tagline;
      if (dto.aboutText !== undefined) patch.aboutText = dto.aboutText;
      if (dto.contactEmail !== undefined) patch.contactEmail = dto.contactEmail;
      if (dto.contactPhone !== undefined) patch.contactPhone = dto.contactPhone;
      if (dto.address !== undefined) patch.address = dto.address;
      if (dto.heroTitle !== undefined) patch.heroTitle = dto.heroTitle;
      if (dto.heroSubtitle !== undefined) patch.heroSubtitle = dto.heroSubtitle;
      if (dto.socialLinks !== undefined) patch.socialLinks = dto.socialLinks;
      if (dto.faqItems !== undefined) patch.faqItems = dto.faqItems;

      if (Object.keys(patch).length === 0) {
        throw new BadRequestException('No fields to update');
      }

      patch.updatedAt = new Date();

      const current = await this.db.select().from(siteSettings).limit(1);
      if (current.length === 0) {
        throw new NotFoundException('Site settings not found');
      }

      const updated = await this.db
        .update(siteSettings)
        .set(patch)
        .where(eq(siteSettings.id, current[0].id))
        .returning();

      this.logger.log('Site settings updated');
      const row = updated[0];
      return {
        id: row.id,
        companyName: row.companyName,
        tagline: row.tagline,
        aboutText: row.aboutText,
        contactEmail: row.contactEmail,
        contactPhone: row.contactPhone,
        address: row.address,
        heroTitle: row.heroTitle,
        heroSubtitle: row.heroSubtitle,
        socialLinks: row.socialLinks as Record<string, string>,
        faqItems: row.faqItems as FaqItem[],
        updatedAt: row.updatedAt.toISOString(),
      };
    } catch (error) {
      this.logger.error('Failed to update site settings', JSON.stringify(error));
      throw error;
    }
  }
}
