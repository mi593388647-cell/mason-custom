import { Controller, Get, Patch, Body, UseGuards } from '@nestjs/common';
import { SiteSettingsService } from './site-settings.service';
import type { SiteSettings, SiteSettingsUpdateRequest } from '@shared/api.interface';
import { AdminAuthGuard } from '../admin-auth/admin-auth.guard';

@Controller('api/site-settings')
export class SiteSettingsController {
  constructor(private readonly siteSettingsService: SiteSettingsService) {}

  @Get()
  async get(): Promise<SiteSettings> {
    return this.siteSettingsService.get();
  }

  @UseGuards(AdminAuthGuard)
  @Patch()
  async update(@Body() dto: SiteSettingsUpdateRequest): Promise<SiteSettings> {
    return this.siteSettingsService.update(dto);
  }
}
