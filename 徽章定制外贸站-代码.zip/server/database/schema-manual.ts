import { sql } from 'drizzle-orm';
import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  uniqueIndex,
  uuid,
  varchar,
  customType,
} from 'drizzle-orm/pg-core';

export const customTimestamptz = customType<{
  data: Date;
  driverData: string;
  config: { precision?: number };
}>({
  dataType(config) {
    const precision = typeof config?.precision !== 'undefined'
      ? ` (${config.precision})`
      : '';
    return `timestamptz${precision}`;
  },
  toDriver(value: Date | string | number) {
    if (value == null) return value as any;
    if (typeof value === 'number') return new Date(value).toISOString();
    if (typeof value === 'string') return value;
    if (value instanceof Date) return value.toISOString();
    throw new Error('Invalid timestamp value');
  },
  fromDriver(value: string | Date): Date {
    if (value instanceof Date) return value;
    return new Date(value);
  },
});

export const userProfile = customType<{
  data: string;
  driverData: string;
}>({
  dataType() {
    return 'user_profile';
  },
  toDriver(value: string) {
    return sql`ROW(${value})::user_profile`;
  },
  fromDriver(value: string) {
    const [userId] = value.slice(1, -1).split(',');
    return userId.trim();
  },
});

export type FileAttachment = {
  bucket_id: string;
  file_path: string;
};

export const fileAttachment = customType<{
  data: FileAttachment;
  driverData: string;
}>({
  dataType() {
    return 'file_attachment';
  },
  toDriver(value: FileAttachment) {
    return sql`ROW(${value.bucket_id},${value.file_path})::file_attachment`;
  },
  fromDriver(value: string): FileAttachment {
    const [bucketId, filePath] = value.slice(1, -1).split(',');
    return { bucket_id: bucketId.trim(), file_path: filePath.trim() };
  },
});

export const adminUsers = pgTable('admin_users', {
  id: uuid('id').primaryKey().defaultRandom(),
  username: varchar('username', { length: 100 }).notNull().unique(),
  passwordHash: varchar('password_hash', { length: 255 }).notNull(),
  createdAt: customTimestamptz('_created_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz('_updated_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex('admin_users_username_key').on(table.username),
]);

export const siteSettings = pgTable('site_settings', {
  id: uuid('id').primaryKey().defaultRandom(),
  companyName: varchar('company_name', { length: 255 }).notNull().default('BadgeCraft'),
  tagline: varchar('tagline', { length: 500 }).notNull(),
  aboutText: text('about_text').notNull(),
  contactEmail: varchar('contact_email', { length: 255 }).notNull(),
  contactPhone: varchar('contact_phone', { length: 50 }).notNull(),
  address: text('address').notNull(),
  heroTitle: varchar('hero_title', { length: 255 }).notNull(),
  heroSubtitle: text('hero_subtitle').notNull(),
  socialLinks: jsonb('social_links').notNull().default('{}'),
  faqItems: jsonb('faq_items').notNull().default('[]'),
  updatedAt: customTimestamptz('_updated_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const inquiries = pgTable('inquiries', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: varchar('name', { length: 255 }).notNull(),
  email: varchar('email', { length: 255 }).notNull(),
  company: varchar('company', { length: 255 }).notNull(),
  country: varchar('country', { length: 100 }).notNull(),
  productType: varchar('product_type', { length: 100 }).notNull(),
  quantity: integer('quantity'),
  designFileUrl: text('design_file_url'),
  designFileName: varchar('design_file_name', { length: 255 }),
  message: text('message').notNull(),
  status: varchar('status', { length: 20 }).notNull().default('pending'),
  createdAt: customTimestamptz('_created_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz('_updated_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index('idx_inquiries_status').on(table.status),
  index('idx_inquiries_created_at').on(table.createdAt),
]);

export const products = pgTable('products', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: varchar('name', { length: 255 }).notNull(),
  slug: varchar('slug', { length: 255 }).notNull().unique(),
  category: varchar('category', { length: 100 }).notNull(),
  description: text('description').notNull(),
  specifications: jsonb('specifications').notNull().default('{}'),
  moq: varchar('moq', { length: 100 }).notNull(),
  priceRange: varchar('price_range', { length: 100 }).notNull(),
  imageUrls: jsonb('image_urls').notNull().default('[]'),
  sortOrder: integer('sort_order').notNull().default(0),
  isActive: boolean('is_active').notNull().default(true),
  createdAt: customTimestamptz('_created_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  createdBy: userProfile('_created_by').default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL
  END`),
  updatedAt: customTimestamptz('_updated_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedBy: userProfile('_updated_by').default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL
  END`),
}, (table) => [
  uniqueIndex('products_slug_key').on(table.slug),
  index('idx_products_category').on(table.category),
  index('idx_products_is_active').on(table.isActive),
  index('idx_products_sort_order').on(table.sortOrder),
]);

export const adminUsersTable = adminUsers;
export const inquiriesTable = inquiries;
export const productsTable = products;
export const siteSettingsTable = siteSettings;
