export type FileAttachment = {
  bucket_id: string;
  file_path: string;
};

// ========== Product ==========
export interface ProductSpecifications {
  material?: string;
  size?: string;
  thickness?: string;
  process?: string;
  plating?: string;
  attachment?: string;
  colors?: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  category: string;
  description: string;
  specifications: ProductSpecifications;
  moq: string;
  priceRange: string;
  imageUrls: string[];
  sortOrder: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ProductListResponse {
  items: Product[];
  total: number;
}

export interface ProductCreateRequest {
  name: string;
  slug: string;
  category: string;
  description: string;
  specifications: ProductSpecifications;
  moq: string;
  priceRange: string;
  imageUrls: string[];
  sortOrder: number;
  isActive: boolean;
}

export interface ProductUpdateRequest {
  name?: string;
  slug?: string;
  category?: string;
  description?: string;
  specifications?: ProductSpecifications;
  moq?: string;
  priceRange?: string;
  imageUrls?: string[];
  sortOrder?: number;
  isActive?: boolean;
}

// ========== Inquiry ==========
export interface Inquiry {
  id: string;
  name: string;
  email: string;
  company: string;
  country: string;
  productType: string;
  quantity: number | null;
  designFileUrl: string | null;
  designFileName: string | null;
  message: string;
  status: "pending" | "processed";
  createdAt: string;
  updatedAt: string;
}

export interface InquiryListResponse {
  items: Inquiry[];
  total: number;
}

export interface InquiryCreateRequest {
  name: string;
  email: string;
  company: string;
  country: string;
  productType: string;
  quantity: number | null;
  designFileUrl: string | null;
  designFileName: string | null;
  message: string;
}

export interface InquiryUpdateStatusRequest {
  status: "pending" | "processed";
}

// ========== Site Settings ==========
export interface SocialLinks {
  website?: string;
  facebook?: string;
  instagram?: string;
  linkedin?: string;
  youtube?: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export interface SiteSettings {
  id: string;
  companyName: string;
  tagline: string;
  aboutText: string;
  contactEmail: string;
  contactPhone: string;
  address: string;
  heroTitle: string;
  heroSubtitle: string;
  socialLinks: SocialLinks;
  faqItems: FaqItem[];
  updatedAt: string;
}

export interface SiteSettingsUpdateRequest {
  companyName?: string;
  tagline?: string;
  aboutText?: string;
  contactEmail?: string;
  contactPhone?: string;
  address?: string;
  heroTitle?: string;
  heroSubtitle?: string;
  socialLinks?: SocialLinks;
  faqItems?: FaqItem[];
}

// ========== Admin Auth ==========
export interface AdminLoginRequest {
  username: string;
  password: string;
}

export interface AdminLoginResponse {
  success: boolean;
  token: string;
  username: string;
}
