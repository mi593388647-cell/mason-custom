# BadgeCraft - Custom Badge B2B Website

## Overview
English-language B2B e-commerce website for custom badge/pin manufacturing. Targets overseas wholesale buyers. Professional, trustworthy factory/supplier branding.

## Tech Stack
- Frontend: React 19 + TypeScript + Tailwind CSS + shadcn/ui
- Backend: NestJS 10 + Drizzle ORM + PostgreSQL
- File storage: dataloom (product images, inquiry attachments)

## Design System

### Visual Style
- **Brand**: Professional manufacturing / B2B supplier aesthetic
- **Language**: All UI text in English
- **Vibe**: Trustworthy, premium quality, industrial precision

### Color Palette
- Primary: Deep navy blue `hsl(215 70% 25%)` — conveys trust, professionalism, industrial quality
- Accent: Gold/bronze `hsl(42 90% 50%)` — premium feel, matches badge/pin metallic theme
- Background: Off-white `hsl(40 20% 97%)`
- Text: Dark slate `hsl(215 25% 15%)`
- Muted text: `hsl(215 10% 45%)`
- Border: Light gray `hsl(215 15% 90%)`

### Typography
- Font: System sans-serif stack (clean, professional)
- Headings: Bold, tight tracking
- Body: 16px base, 1.6 line-height

### Spacing Scale
- xs: 0.5rem (8px)
- sm: 1rem (16px)
- md: 1.5rem (24px)
- lg: 2.5rem (40px)
- xl: 4rem (64px)

### Layout
- Max content width: 1200px
- Section padding: 80px vertical on desktop, 48px on mobile
- Card padding: 24px
- Gap between cards: 24px

### Components
- Buttons: Solid primary (navy) with white text, outline variant for secondary
- Cards: White background, subtle border, soft shadow on hover
- Forms: Clean labels, generous input padding, clear validation states

## Information Architecture

### Frontend Routes (Public)
- `/` — Home (hero, features, products preview, process, CTA)
- `/products` — Products catalog (all categories)
- `/products/:slug` — Product detail page
- `/custom-process` — Custom badge process page
- `/inquiry` — Inquiry / quote form
- `/about` — About us / company info
- `/faq` — FAQ page
- `/contact` — Contact information

### Admin Routes (Protected)
- `/admin/login` — Admin login
- `/admin/dashboard` — Dashboard overview
- `/admin/products` — Product management (list)
- `/admin/products/new` — Add product
- `/admin/products/:id/edit` — Edit product
- `/admin/inquiries` — Inquiry management (list + detail)
- `/admin/settings` — Site settings

## Database Schema

### products
- id, name, slug, category, description, specifications(JSONB), moq, price_range, image_urls(JSONB), sort_order, is_active, _created_at, _created_by, _updated_at, _updated_by

### inquiries
- id, name, email, company, country, product_type, quantity, design_attachment, message, status(pending/processed), _created_at, _updated_at

### site_settings
- id (single row), company_name, tagline, about_text, contact_email, contact_phone, address, social_links(JSONB), hero_title, hero_subtitle, _updated_at

### admin_users (simple admin auth)
- id, username, password_hash, _created_at, _updated_at

## Modules

### Backend
- `products` — Product CRUD + public listing
- `inquiries` — Inquiry submission + admin management
- `site-settings` — Site settings CRUD
- `admin-auth` — Admin login/auth

### Frontend
- Pages under `pages/` matching routes above
- API modules under `api/`
- Shared components: Navbar, Footer, ProductCard, etc.

## Key Features Priority
1. Product catalog with categories
2. Inquiry form with file upload
3. Admin product management
4. Admin inquiry management
5. Site settings editor
