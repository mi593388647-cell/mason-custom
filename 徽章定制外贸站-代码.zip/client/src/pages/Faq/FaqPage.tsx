import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { siteSettingsApi } from '@client/src/api/index';
import type { FaqItem } from '@shared/api.interface';

const defaultFaqItems: FaqItem[] = [
  {
    question: 'What is your minimum order quantity?',
    answer:
      'MOQ starts from 50 pieces for most badge types. Some products like challenge coins may have higher minimums. Contact our sales team for specific product MOQ details.',
  },
  {
    question: 'How long does production take?',
    answer:
      'Standard production takes 15-20 business days after sample confirmation. Rush orders can be accommodated for an additional fee — please inquire about our expedited service.',
  },
  {
    question: 'Can you produce custom designs?',
    answer:
      'Yes! Send us your artwork and we will create a digital proof for your approval before production begins. Our in-house design team can also assist with artwork refinement.',
  },
  {
    question: 'What file formats do you accept?',
    answer:
      'We accept AI, EPS, PDF, PSD, and high-resolution PNG/JPG files. Vector files (AI, EPS, PDF) are preferred for the best quality results.',
  },
  {
    question: 'Do you offer free samples?',
    answer:
      'We charge a small sample fee which can be deducted from your bulk order. Sample production typically takes 5-7 business days. Existing stock samples may be available at no charge — just cover shipping.',
  },
  {
    question: 'What payment methods do you accept?',
    answer:
      'We accept T/T bank transfer, PayPal, Western Union, and Alibaba Trade Assurance. For bulk orders, we typically require a 30% deposit with the balance due before shipment.',
  },
];

const FaqPage = () => {
  const [faqItems, setFaqItems] = useState<FaqItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    siteSettingsApi
      .getSiteSettings()
      .then((data) => {
        if (cancelled) return;
        if (data.faqItems && data.faqItems.length > 0) {
          setFaqItems(data.faqItems);
        } else {
          setFaqItems(defaultFaqItems);
        }
      })
      .catch(() => {
        if (!cancelled) setFaqItems(defaultFaqItems);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const displayItems = faqItems.length > 0 ? faqItems : defaultFaqItems;
  const defaultValue = displayItems[0]?.question ?? 'item-0';

  return (
    <div className="bg-background">
      {/* Page Header */}
      <section className="bg-primary text-primary-foreground py-16 md:py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex justify-center mb-4">
            <div className="w-14 h-14 rounded-full bg-white/10 flex items-center justify-center">
              <HelpCircle className="w-7 h-7 text-accent" />
            </div>
          </div>
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight mb-4">
            Frequently Asked Questions
          </h1>
          <p className="text-base md:text-lg text-white/80 max-w-2xl mx-auto">
            Find answers to common questions about our custom badge services
          </p>
        </div>
      </section>

      {/* FAQ Accordion */}
      <section className="py-12 md:py-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <div
                  key={i}
                  className="border border-border rounded-lg p-5 bg-card"
                >
                  <div className="h-5 bg-muted rounded w-3/4 animate-pulse mb-3" />
                  <div className="h-4 bg-muted rounded w-full animate-pulse" />
                </div>
              ))}
            </div>
          ) : (
            <Accordion
              type="single"
              collapsible
              defaultValue={defaultValue}
              className="bg-card border border-border rounded-xl px-6 shadow-sm"
            >
              {displayItems.map((item, index) => (
                <AccordionItem
                  key={item.question}
                  value={item.question}
                  className={index === 0 ? 'border-t-0' : ''}
                >
                  <AccordionTrigger className="text-left text-foreground font-semibold py-5 hover:no-underline">
                    {item.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          )}
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="py-12 md:py-16 bg-muted/40">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3">
            Have more questions?
          </h2>
          <p className="text-muted-foreground mb-8">
            Contact our sales team and we&apos;ll get back to you within 24
            hours.
          </p>
          <Link to="/contact">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
            >
              Contact Us
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default FaqPage;
