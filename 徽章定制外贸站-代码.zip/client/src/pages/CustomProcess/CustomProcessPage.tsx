import { Link } from 'react-router-dom';
import {
  Upload,
  Palette,
  FileCheck2,
  Package2,
  Factory,
  Truck,
} from 'lucide-react';
import { Button } from '@client/src/components/ui/button';

interface ProcessStep {
  step: number;
  title: string;
  icon: React.ReactNode;
  points: string[];
}

const STEPS: ProcessStep[] = [
  {
    step: 1,
    title: 'Design Submission',
    icon: <Upload className="w-6 h-6" />,
    points: [
      'Send us your artwork via email or our online inquiry form',
      'Accepted formats: AI, EPS, PDF, PSD, high-res PNG/JPG',
      'Our design team reviews your files within 24 hours',
    ],
  },
  {
    step: 2,
    title: 'Free Artwork Proof',
    icon: <Palette className="w-6 h-6" />,
    points: [
      'We create a digital mockup of your custom badge design',
      'Unlimited revisions until you\'re 100% satisfied',
      'Confirm colors, size, plating, and attachment',
    ],
  },
  {
    step: 3,
    title: 'Quote & Order Confirmation',
    icon: <FileCheck2 className="w-6 h-6" />,
    points: [
      'Receive a detailed quote with pricing and lead time',
      'Confirm your order with a 30-50% deposit',
      'Production schedule is set immediately',
    ],
  },
  {
    step: 4,
    title: 'Sample Production (Optional)',
    icon: <Package2 className="w-6 h-6" />,
    points: [
      'Physical sample available for quality verification',
      'Sample time: 5-7 business days',
      'Sample fee deductible from bulk order',
    ],
  },
  {
    step: 5,
    title: 'Mass Production',
    icon: <Factory className="w-6 h-6" />,
    points: [
      'Full production run begins after sample approval',
      'Standard production: 15-20 business days',
      'Rush service available for urgent orders',
      'Quality inspection at every stage',
    ],
  },
  {
    step: 6,
    title: 'Quality Check & Shipping',
    icon: <Truck className="w-6 h-6" />,
    points: [
      '100% quality inspection before packaging',
      'Multiple shipping options: DHL, FedEx, UPS, by sea',
      'Tracking number provided upon shipment',
      'Delivery time: 3-7 days (express), 15-30 days (sea)',
    ],
  },
];

export default function CustomProcessPage() {
  return (
    <div className="bg-background">
      {/* Page Header */}
      <section className="bg-primary text-primary-foreground">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 text-center">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight mb-4">
            Our Custom Badge Process
          </h1>
          <p className="text-lg text-white/80 max-w-2xl mx-auto">
            From design to delivery, we guide you every step of the way
          </p>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-16 lg:py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative">
            {/* Vertical connecting line */}
            <div
              className="absolute left-5 lg:left-1/2 top-0 bottom-0 w-0.5 bg-border"
              aria-hidden="true"
            />

            <div className="space-y-12">
              {STEPS.map((stepItem, index) => {
                const isEven = index % 2 === 0;
                return (
                  <div
                    key={stepItem.step}
                    className={`relative flex ${
                      isEven ? 'lg:flex-row' : 'lg:flex-row-reverse'
                    } items-start gap-6`}
                  >
                    {/* Step Circle */}
                    <div className="relative z-10 shrink-0">
                      <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-full bg-accent text-accent-foreground flex items-center justify-center font-bold shadow-md">
                        {stepItem.step}
                      </div>
                    </div>

                    {/* Content Card */}
                    <div
                      className={`flex-1 lg:flex-none lg:w-[calc(50%-2.5rem)] ${
                        isEven ? '' : 'lg:text-right'
                      }`}
                    >
                      <div className="bg-card border border-card-border rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                        <div
                          className={`flex items-center gap-3 mb-4 ${
                            isEven ? '' : 'lg:flex-row-reverse'
                          }`}
                        >
                          <div className="w-10 h-10 rounded-lg bg-accent/10 text-accent flex items-center justify-center">
                            {stepItem.icon}
                          </div>
                          <h3 className="text-xl font-bold text-primary">
                            Step {stepItem.step}: {stepItem.title}
                          </h3>
                        </div>
                        <ul
                          className={`space-y-2 text-muted-foreground text-sm leading-relaxed ${
                            isEven ? '' : 'lg:text-right'
                          }`}
                        >
                          {stepItem.points.map((point: string, pIdx: number) => (
                            <li
                              key={pIdx}
                              className={`flex ${
                                isEven ? '' : 'lg:flex-row-reverse'
                              } gap-2`}
                            >
                              <span className="text-accent shrink-0">•</span>
                              <span>{point}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-secondary/50 py-16 lg:py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl lg:text-3xl font-bold text-primary mb-3">
            Ready to Start Your Custom Badge Project?
          </h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Get your free quote today — no obligation.
          </p>
          <Link to="/inquiry">
            <Button
              size="lg"
              className="bg-accent text-accent-foreground hover:bg-accent/90 border-accent/80 font-semibold"
            >
              Get Your Free Quote
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
