import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Mail,
  Phone,
  MapPin,
  Facebook,
  Instagram,
  Linkedin,
  Youtube,
  ArrowRight,
  MessageSquare,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { siteSettingsApi } from '@client/src/api/index';
import type { SiteSettings } from '@shared/api.interface';
import { UniversalLink } from '@lark-apaas/client-toolkit/components/UniversalLink';

const contactCards = [
  {
    icon: Mail,
    title: 'Email Us',
    label: 'contact_email',
    fallback: 'Mason_Sn.co@outlook.com',
    subtitle: 'We reply within 24 hours',
    hrefPrefix: 'mailto:',
  },
  {
    icon: Phone,
    title: 'Call Us',
    label: 'contact_phone',
    fallback: '+86-138-0000-0000',
    subtitle: 'Mon-Sat, 9:00-18:00 GMT+8',
    hrefPrefix: 'tel:',
  },
  {
    icon: MapPin,
    title: 'Visit Us',
    label: 'address',
    fallback: 'No. 88 Industrial Road, Shenzhen, Guangdong, China',
    subtitle: 'By appointment only',
    hrefPrefix: '',
  },
] as const;

const socialChannels = [
  { icon: Facebook, label: 'Facebook', key: 'facebook' },
  { icon: Instagram, label: 'Instagram', key: 'instagram' },
  { icon: Linkedin, label: 'LinkedIn', key: 'linkedin' },
  { icon: Youtube, label: 'YouTube', key: 'youtube' },
] as const;

const ContactPage = () => {
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    siteSettingsApi
      .getSiteSettings()
      .then((data) => {
        if (!cancelled) setSettings(data);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const getContactValue = (label: string, fallback: string): string => {
    if (!settings) return fallback;
    switch (label) {
      case 'contact_email':
        return settings.contactEmail || fallback;
      case 'contact_phone':
        return settings.contactPhone || fallback;
      case 'address':
        return settings.address || fallback;
      default:
        return fallback;
    }
  };

  const getSocialUrl = (key: string): string => {
    return settings?.socialLinks?.[key as keyof typeof settings.socialLinks] || '#';
  };

  return (
    <div className="bg-background">
      {/* Page Header */}
      <section className="bg-primary text-primary-foreground py-16 md:py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex justify-center mb-4">
            <div className="w-14 h-14 rounded-full bg-white/10 flex items-center justify-center">
              <MessageSquare className="w-7 h-7 text-accent" />
            </div>
          </div>
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight mb-4">
            Contact Us
          </h1>
          <p className="text-base md:text-lg text-white/80 max-w-2xl mx-auto">
            We&apos;d love to hear from you. Reach out to our team anytime.
          </p>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="py-12 md:py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {contactCards.map((card) => {
              const Icon = card.icon;
              const value = loading ? '' : getContactValue(card.label, card.fallback);
              const href = card.hrefPrefix ? `${card.hrefPrefix}${value}` : undefined;

              return (
                <Card
                  key={card.title}
                  className="hover:shadow-md transition-shadow duration-300 border-border"
                >
                  <CardContent className="pt-6 text-center">
                    <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-5">
                      <Icon className="w-7 h-7 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      {card.title}
                    </h3>
                    {loading ? (
                      <div className="h-5 bg-muted rounded w-3/4 mx-auto animate-pulse mb-2" />
                    ) : href ? (
                      <UniversalLink
                        to={href}
                        className="text-foreground hover:text-accent transition-colors font-medium break-words"
                      >
                        {value}
                      </UniversalLink>
                    ) : (
                      <p className="text-foreground font-medium break-words">
                        {value}
                      </p>
                    )}
                    <p className="text-sm text-muted-foreground mt-2">
                      {card.subtitle}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Get in Touch Section */}
      <section className="py-12 md:py-20 bg-muted/40">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-accent font-semibold text-sm uppercase tracking-wider mb-3">
            Get a Quote
          </p>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground mb-4">
            Send Us a Message
          </h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            For quote requests, please use our inquiry form for faster response.
            Our sales team will get back to you within 24 hours with a detailed
            quotation.
          </p>
          <Link to="/inquiry">
            <Button
              size="lg"
              className="bg-accent text-accent-foreground hover:bg-accent/90 font-semibold"
            >
              Go to Inquiry Form
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Social Media */}
      <section className="py-12 md:py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-lg font-semibold text-foreground mb-4">
            Follow Us
          </h3>
          <p className="text-muted-foreground mb-6">
            Connect with us on social media for the latest updates and product
            showcases.
          </p>
          <div className="flex items-center justify-center gap-4">
            {socialChannels.map((social) => {
              const Icon = social.icon;
              const url = getSocialUrl(social.key);
              return (
                <UniversalLink
                  key={social.label}
                  to={url}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.label}
                  className="w-12 h-12 rounded-full bg-card border border-border flex items-center justify-center text-muted-foreground hover:text-accent hover:border-accent/50 transition-colors"
                >
                  <Icon className="w-5 h-5" />
                </UniversalLink>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;
