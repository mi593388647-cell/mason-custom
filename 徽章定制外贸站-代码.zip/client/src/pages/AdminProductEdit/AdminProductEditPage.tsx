import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { ArrowLeft, Save, Plus } from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';

import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import { Switch } from '@client/src/components/ui/switch';
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardFooter,
} from '@client/src/components/ui/card';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from '@client/src/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';

import { productsApi } from '@client/src/api/index';
import type {
  Product,
  ProductCreateRequest,
  ProductUpdateRequest,
  ProductSpecifications,
} from '@shared/api.interface';

const productSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  slug: z.string().min(1, 'Slug is required'),
  category: z.string().min(1, 'Category is required'),
  description: z.string(),
  moq: z.string(),
  priceRange: z.string(),
  sortOrder: z.coerce.number(),
  isActive: z.boolean(),
  material: z.string(),
  size: z.string(),
  thickness: z.string(),
  process: z.string(),
  plating: z.string(),
  attachment: z.string(),
  colors: z.string(),
  imageUrls: z.string(),
});

const CATEGORIES = [
  { value: 'soft-enamel', label: 'Soft Enamel' },
  { value: 'die-struck', label: 'Die Struck' },
  { value: 'pvc', label: 'PVC' },
  { value: 'hard-enamel', label: 'Hard Enamel' },
  { value: 'other', label: 'Other' },
];

const AdminProductEditPage = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const isEditMode = Boolean(id);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const form = useForm({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: '',
      slug: '',
      category: '',
      description: '',
      moq: '',
      priceRange: '',
      sortOrder: 0,
      isActive: true,
      material: '',
      size: '',
      thickness: '',
      process: '',
      plating: '',
      attachment: '',
      colors: '',
      imageUrls: '',
    },
  });

  useEffect(() => {
    if (!isEditMode || !id) return;

    const loadProduct = async () => {
      setLoading(true);
      try {
        const response = await productsApi.getAdminProducts();
        const product: Product | undefined = response.items.find(
          (p: Product) => p.id === id,
        );
        if (!product) {
          toast.error('Product not found');
          navigate('/admin/products');
          return;
        }
        const specs: ProductSpecifications = product.specifications || {};
        form.reset({
          name: product.name,
          slug: product.slug,
          category: product.category,
          description: product.description || '',
          moq: product.moq || '',
          priceRange: product.priceRange || '',
          sortOrder: product.sortOrder ?? 0,
          isActive: product.isActive,
          material: specs.material || '',
          size: specs.size || '',
          thickness: specs.thickness || '',
          process: specs.process || '',
          plating: specs.plating || '',
          attachment: specs.attachment || '',
          colors: specs.colors || '',
          imageUrls: (product.imageUrls || []).join('\n'),
        });
      } catch (error) {
        logger.error('Failed to load product', error);
        toast.error('Failed to load product');
      } finally {
        setLoading(false);
      }
    };

    loadProduct();
  }, [isEditMode, id, form]);

  const onSubmit = async (data: unknown) => {
    const parsed = productSchema.parse(data);
    setSaving(true);
    try {
      const imageUrls = parsed.imageUrls
        .split('\n')
        .map((url: string) => url.trim())
        .filter(Boolean);

      const specifications: ProductSpecifications = {
        material: parsed.material || undefined,
        size: parsed.size || undefined,
        thickness: parsed.thickness || undefined,
        process: parsed.process || undefined,
        plating: parsed.plating || undefined,
        attachment: parsed.attachment || undefined,
        colors: parsed.colors || undefined,
      };

      if (isEditMode && id) {
        const updateData: ProductUpdateRequest = {
          name: parsed.name,
          slug: parsed.slug,
          category: parsed.category,
          description: parsed.description,
          moq: parsed.moq,
          priceRange: parsed.priceRange,
          sortOrder: parsed.sortOrder,
          isActive: parsed.isActive,
          specifications,
          imageUrls,
        };
        await productsApi.updateProduct(id, updateData);
        toast.success('Product updated successfully');
      } else {
        const createData: ProductCreateRequest = {
          name: parsed.name,
          slug: parsed.slug,
          category: parsed.category,
          description: parsed.description,
          moq: parsed.moq,
          priceRange: parsed.priceRange,
          sortOrder: parsed.sortOrder,
          isActive: parsed.isActive,
          specifications,
          imageUrls,
        };
        await productsApi.createProduct(createData);
        toast.success('Product created successfully');
      }
      navigate('/admin/products');
    } catch (error) {
      logger.error('Failed to save product', error);
      toast.error('Failed to save product');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-muted-foreground">Loading product...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate('/admin/products')}
          className="gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            {isEditMode ? 'Edit Product' : 'New Product'}
          </h1>
          <p className="text-sm text-muted-foreground">
            {isEditMode
              ? 'Update product details and specifications'
              : 'Create a new product listing'}
          </p>
        </div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Basic Info */}
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem className="flex-1 min-w-[240px]">
                      <FormLabel>
                        Name <span className="text-destructive">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Classic Soft Enamel Pins" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="slug"
                  render={({ field }) => (
                    <FormItem className="flex-1 min-w-[240px]">
                      <FormLabel>
                        Slug <span className="text-destructive">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. soft-enamel-pins" {...field} />
                      </FormControl>
                      <FormDescription>
                        URL-friendly name, lowercase with hyphens
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex flex-wrap gap-4">
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem className="flex-1 min-w-[240px]">
                      <FormLabel>
                        Category <span className="text-destructive">*</span>
                      </FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        value={field.value || undefined}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {CATEGORIES.map((cat) => (
                            <SelectItem key={cat.value} value={cat.value}>
                              {cat.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="sortOrder"
                  render={({ field }) => (
                    <FormItem className="flex-1 min-w-[160px]">
                      <FormLabel>Sort Order</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          value={field.value as number}
                          onChange={field.onChange}
                          onBlur={field.onBlur}
                          name={field.name}
                          ref={field.ref}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="isActive"
                  render={({ field }) => (
                    <FormItem className="flex-1 min-w-[160px]">
                      <FormLabel>Status</FormLabel>
                      <div className="flex items-center gap-3 h-10">
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <span className="text-sm text-muted-foreground">
                          {field.value ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          {/* Product Info */}
          <Card>
            <CardHeader>
              <CardTitle>Product Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea
                        rows={4}
                        placeholder="Product description..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex flex-wrap gap-4">
                <FormField
                  control={form.control}
                  name="moq"
                  render={({ field }) => (
                    <FormItem className="flex-1 min-w-[200px]">
                      <FormLabel>MOQ</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 50 pcs" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="priceRange"
                  render={({ field }) => (
                    <FormItem className="flex-1 min-w-[200px]">
                      <FormLabel>Price Range</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. $0.50 - $3.50" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          {/* Specifications */}
          <Card>
            <CardHeader>
              <CardTitle>Specifications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="material"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Material</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Iron, Brass" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="size"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Size</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 1.5 inch" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="thickness"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Thickness</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 1.2mm" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="process"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Process</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Soft Enamel" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="plating"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Plating</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Gold, Nickel" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="attachment"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Attachment</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Butterfly Clutch" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="colors"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Colors</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Pantone matched" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          {/* Images */}
          <Card>
            <CardHeader>
              <CardTitle>Images</CardTitle>
            </CardHeader>
            <CardContent>
              <FormField
                control={form.control}
                name="imageUrls"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Image URLs</FormLabel>
                    <FormControl>
                      <Textarea
                        rows={5}
                        placeholder="Enter one image URL per line&#10;https://example.com/image1.jpg&#10;https://example.com/image2.jpg"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Enter one URL per line. Supports 1-3 images.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate('/admin/products')}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={saving} className="gap-2">
              {isEditMode ? <Save className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
              {isEditMode ? 'Save Changes' : 'Create Product'}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default AdminProductEditPage;
