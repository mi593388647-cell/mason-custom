import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Plus,
  Pencil,
  Trash2,
  Package,
  Loader2,
  AlertTriangle,
} from 'lucide-react';
import type { Product } from '@shared/api.interface';
import { productsApi } from '@client/src/api/index';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import { Switch } from '@client/src/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';
import { Card, CardContent } from '@client/src/components/ui/card';
import Image from '@client/src/components/ui/image';

const AdminProductsPage = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [togglingId, setTogglingId] = useState<string | null>(null);

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const res = await productsApi.getAdminProducts();
      const sorted = [...res.items].sort((a: Product, b: Product) =>
        a.sortOrder - b.sortOrder
      );
      setProducts(sorted);
    } catch (err) {
      logger.error('Failed to load products', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const handleToggleActive = async (product: Product) => {
    setTogglingId(product.id);
    try {
      const updated = await productsApi.updateProduct(product.id, {
        isActive: !product.isActive,
      });
      setProducts((prev) =>
        prev.map((p: Product) => (p.id === product.id ? updated : p))
      );
    } catch (err) {
      logger.error('Failed to toggle product status', err);
    } finally {
      setTogglingId(null);
    }
  };

  const openDeleteDialog = (product: Product) => {
    setProductToDelete(product);
    setDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!productToDelete) return;
    setDeleting(true);
    try {
      await productsApi.deleteProduct(productToDelete.id);
      setProducts((prev) => prev.filter((p: Product) => p.id !== productToDelete.id));
      setDeleteDialogOpen(false);
      setProductToDelete(null);
    } catch (err) {
      logger.error('Failed to delete product', err);
    } finally {
      setDeleting(false);
    }
  };

  const sortedProducts = [...products].sort((a: Product, b: Product) =>
    a.sortOrder - b.sortOrder
  );

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Products</h1>
          <p className="text-muted-foreground mt-1">
            Manage your product catalog
          </p>
        </div>
        <Button asChild>
          <Link to="/admin/products/new">
            <Plus className="w-4 h-4" />
            Add Product
          </Link>
        </Button>
      </div>

      {/* Product Table */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6">
              {/* Skeleton rows */}
              <div className="space-y-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-4 h-16 bg-muted/50 rounded animate-pulse"
                  >
                    <div className="w-16 h-16 bg-muted rounded" />
                    <div className="flex-1 space-y-2">
                      <div className="h-4 w-1/3 bg-muted rounded" />
                      <div className="h-3 w-1/4 bg-muted rounded" />
                    </div>
                    <div className="w-20 h-4 bg-muted rounded" />
                    <div className="w-16 h-4 bg-muted rounded" />
                    <div className="w-24 h-4 bg-muted rounded" />
                    <div className="w-12 h-4 bg-muted rounded" />
                    <div className="w-24 h-6 bg-muted rounded" />
                  </div>
                ))}
              </div>
            </div>
          ) : sortedProducts.length === 0 ? (
            <div className="text-center py-16">
              <Package className="w-12 h-12 mx-auto mb-4 text-muted-foreground/40" />
              <p className="text-muted-foreground mb-4">
                No products yet. Click &quot;Add Product&quot; to create your first product.
              </p>
              <Button asChild>
                <Link to="/admin/products/new">
                  <Plus className="w-4 h-4" />
                  Add Product
                </Link>
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-16">Image</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Price Range</TableHead>
                    <TableHead>MOQ</TableHead>
                    <TableHead>Sort Order</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sortedProducts.map((product: Product) => (
                    <TableRow key={product.id}>
                      <TableCell>
                        <div className="w-12 h-12 rounded-md overflow-hidden bg-muted flex items-center justify-center">
                          {product.imageUrls && product.imageUrls.length > 0 ? (
                            <Image
                              src={product.imageUrls[0]}
                              alt={product.name}
                              width={48}
                              height={48}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <Package className="w-5 h-5 text-muted-foreground/40" />
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{product.name}</TableCell>
                      <TableCell className="text-muted-foreground capitalize">
                        {product.category || '-'}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {product.priceRange || '-'}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {product.moq || '-'}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {product.sortOrder}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={product.isActive}
                            onCheckedChange={() => handleToggleActive(product)}
                            disabled={togglingId === product.id}
                          />
                          {togglingId === product.id ? (
                            <Loader2 className="w-3.5 h-3.5 text-muted-foreground animate-spin" />
                          ) : (
                            <Badge
                              variant={product.isActive ? 'default' : 'secondary'}
                              className={
                                product.isActive
                                  ? 'bg-green-600 text-white border-transparent'
                                  : 'bg-gray-200 text-gray-600 border-transparent'
                              }
                            >
                              {product.isActive ? 'Active' : 'Inactive'}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            asChild
                            variant="outline"
                            size="sm"
                          >
                            <Link to={`/admin/products/${product.id}/edit`}>
                              <Pencil className="w-3.5 h-3.5" />
                              Edit
                            </Link>
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-destructive hover:text-destructive"
                            onClick={() => openDeleteDialog(product)}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            Delete
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-destructive" />
              Delete Product
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete{' '}
              <span className="font-medium text-foreground">
                {productToDelete?.name}
              </span>
              ? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
              disabled={deleting}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={deleting}
            >
              {deleting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                'Delete'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminProductsPage;
