import { useEffect, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { Eye, CheckCircle, Clock, Inbox, Download } from 'lucide-react';

import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from '@client/src/components/ui/card';
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from '@client/src/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@client/src/components/ui/dialog';
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
} from '@client/src/components/ui/empty';

import { inquiriesApi } from '@client/src/api/index';
import type { Inquiry } from '@shared/api.interface';
import { UniversalLink } from '@lark-apaas/client-toolkit/components/UniversalLink';

type FilterStatus = 'all' | 'pending' | 'processed';

const AdminInquiriesPage = () => {
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<FilterStatus>('all');
  const [selectedInquiry, setSelectedInquiry] = useState<Inquiry | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [updating, setUpdating] = useState(false);

  const loadInquiries = async () => {
    setLoading(true);
    try {
      const statusParam = filter === 'all' ? undefined : filter;
      const response = await inquiriesApi.getInquiries(statusParam);
      setInquiries(response.items);
    } catch (error) {
      logger.error('Failed to load inquiries', error);
      toast.error('Failed to load inquiries');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInquiries();
  }, [filter]);

  const handleView = (inquiry: Inquiry) => {
    setSelectedInquiry(inquiry);
    setDetailOpen(true);
  };

  const handleToggleStatus = async (inquiry: Inquiry) => {
    setUpdating(true);
    try {
      const newStatus: 'pending' | 'processed' =
        inquiry.status === 'pending' ? 'processed' : 'pending';
      await inquiriesApi.updateInquiryStatus(inquiry.id, newStatus);
      toast.success(
        `Inquiry marked as ${newStatus === 'processed' ? 'Processed' : 'Pending'}`,
      );
      setSelectedInquiry(null);
      setDetailOpen(false);
      loadInquiries();
    } catch (error) {
      logger.error('Failed to update inquiry status', error);
      toast.error('Failed to update status');
    } finally {
      setUpdating(false);
    }
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const filterButtons: { value: FilterStatus; label: string }[] = [
    { value: 'all', label: 'All' },
    { value: 'pending', label: 'Pending' },
    { value: 'processed', label: 'Processed' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Inquiries</h1>
          <p className="text-sm text-muted-foreground">
            Manage customer inquiries and quote requests
          </p>
        </div>
        <div className="flex gap-1 bg-muted rounded-lg p-1">
          {filterButtons.map((btn) => (
            <Button
              key={btn.value}
              variant={filter === btn.value ? 'secondary' : 'ghost'}
              size="sm"
              onClick={() => setFilter(btn.value)}
              className="capitalize"
            >
              {btn.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="flex items-center justify-center py-16">
              <div className="text-muted-foreground">Loading inquiries...</div>
            </div>
          ) : inquiries.length === 0 ? (
            <div className="py-16">
              <Empty>
                <EmptyHeader>
                  <EmptyMedia variant="icon">
                    <Inbox className="size-6" />
                  </EmptyMedia>
                  <EmptyTitle>No inquiries yet.</EmptyTitle>
                  <EmptyDescription>
                    {filter === 'all'
                      ? 'When customers submit inquiries, they will appear here.'
                      : `No ${filter} inquiries.`}
                  </EmptyDescription>
                </EmptyHeader>
              </Empty>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Company</TableHead>
                    <TableHead>Product Type</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {inquiries.map((inquiry: Inquiry) => (
                    <TableRow key={inquiry.id}>
                      <TableCell className="font-medium">
                        {inquiry.name}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {inquiry.email}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {inquiry.company || '-'}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {inquiry.productType || '-'}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {inquiry.quantity?.toLocaleString() || '-'}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            inquiry.status === 'pending'
                              ? 'secondary'
                              : 'default'
                          }
                          className={
                            inquiry.status === 'pending'
                              ? 'bg-amber-100 text-amber-800 hover:bg-amber-100'
                              : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-100'
                          }
                        >
                          {inquiry.status === 'pending'
                            ? 'Pending'
                            : 'Processed'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {formatDate(inquiry.createdAt)}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleView(inquiry)}
                            className="gap-1"
                          >
                            <Eye className="w-4 h-4" />
                            View
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Inquiry Details</DialogTitle>
            <DialogDescription>
              View and manage the inquiry details
            </DialogDescription>
          </DialogHeader>

          {selectedInquiry && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <div className="text-sm font-medium text-muted-foreground mb-1">
                    Name
                  </div>
                  <div className="text-foreground">{selectedInquiry.name}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-muted-foreground mb-1">
                    Email
                  </div>
                  <div className="text-foreground break-words">
                    {selectedInquiry.email}
                  </div>
                </div>
                <div>
                  <div className="text-sm font-medium text-muted-foreground mb-1">
                    Company
                  </div>
                  <div className="text-foreground">
                    {selectedInquiry.company || '-'}
                  </div>
                </div>
                <div>
                  <div className="text-sm font-medium text-muted-foreground mb-1">
                    Country
                  </div>
                  <div className="text-foreground">
                    {selectedInquiry.country || '-'}
                  </div>
                </div>
                <div>
                  <div className="text-sm font-medium text-muted-foreground mb-1">
                    Product Type
                  </div>
                  <div className="text-foreground">
                    {selectedInquiry.productType || '-'}
                  </div>
                </div>
                <div>
                  <div className="text-sm font-medium text-muted-foreground mb-1">
                    Quantity
                  </div>
                  <div className="text-foreground">
                    {selectedInquiry.quantity?.toLocaleString() || '-'}
                  </div>
                </div>
                <div>
                  <div className="text-sm font-medium text-muted-foreground mb-1">
                    Status
                  </div>
                  <Badge
                    variant={
                      selectedInquiry.status === 'pending'
                        ? 'secondary'
                        : 'default'
                    }
                    className={
                      selectedInquiry.status === 'pending'
                        ? 'bg-amber-100 text-amber-800 hover:bg-amber-100'
                        : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-100'
                    }
                  >
                    {selectedInquiry.status === 'pending'
                      ? 'Pending'
                      : 'Processed'}
                  </Badge>
                </div>
                <div>
                  <div className="text-sm font-medium text-muted-foreground mb-1">
                    Submitted Date
                  </div>
                  <div className="text-foreground">
                    {formatDate(selectedInquiry.createdAt)}
                  </div>
                </div>
              </div>

              {selectedInquiry.designFileUrl && (
                <div>
                  <div className="text-sm font-medium text-muted-foreground mb-1">
                    Design File
                  </div>
                  <UniversalLink
                    to={selectedInquiry.designFileUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-primary hover:underline"
                  >
                    <Download className="w-4 h-4" />
                    {selectedInquiry.designFileName || 'Download design file'}
                  </UniversalLink>
                </div>
              )}

              <div>
                <div className="text-sm font-medium text-muted-foreground mb-1">
                  Message
                </div>
                <div className="text-foreground bg-muted/50 rounded-md p-3 whitespace-pre-wrap text-sm">
                  {selectedInquiry.message || '-'}
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => setDetailOpen(false)}
            >
              Close
            </Button>
            <Button
              onClick={() =>
                selectedInquiry && handleToggleStatus(selectedInquiry)
              }
              disabled={updating}
              variant={
                selectedInquiry?.status === 'pending' ? 'default' : 'secondary'
              }
              className="gap-2"
            >
              {selectedInquiry?.status === 'pending' ? (
                <>
                  <CheckCircle className="w-4 h-4" />
                  Mark as Processed
                </>
              ) : (
                <>
                  <Clock className="w-4 h-4" />
                  Mark as Pending
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminInquiriesPage;
