import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Factory,
  Package,
  Clock,
  Award,
  Upload,
  Palette,
  CheckCircle2,
  Truck,
  ShieldCheck,
  Medal,
  Globe2,
  Percent,
  ArrowRight,
} from 'lucide-react';
import type { Product, SiteSettings } from '@shared/api.interface';
import { productsApi, siteSettingsApi } from '@client/src/api/index';
import ProductCard from '@client/src/components/ProductCard';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import Image from '@client/src/components/ui/image';

const HERO_IMAGE_URL =
  '/spark/app/app_17e3mfx3m35/runtime/api/v1/storage/object/bucket_aadku7kl5iujs_static/static%2Faadku7guee6hw_ve_miaoda';

const FACTORY_IMAGE_URL =
  '/spark/app/app_17e3mfx3m35/runtime/api/v1/storage/object/bucket_aadku7kl5iujs_static/static%2Faadku7ga4twfs_ve_miaoda';

const FEATURES = [
  {
    icon: Factory,
    title: 'Factory Direct Pricing',
    description:
      'Cut out the middleman. Our in-house manufacturing delivers premium quality at competitive prices directly from our factory floor.',
  },
  {
    icon: Package,
    title: 'Low MOQ',
    description:
      'Start from just 50 pieces. Perfect for small businesses, events, and test orders without compromising on quality.',
  },
  {
    icon: Clock,
    title: 'Fast Turnaround',
    description:
      'Get your badges in 15–20 days. Streamlined production and dedicated account managers keep every order on schedule.',
  },
  {
    icon: Award,
    title: 'OEM & ODM Expertise',
    description:
      '15+ years of custom badge manufacturing. From concept to finished product, our team handles every detail.',
  },
];

const PROCESS_STEPS = [
  {
    number: '01',
    icon: Upload,
    title: 'Send Your Design',
    description:
      'Share your logo, artwork, or idea. Any format works — our designers will prepare a production-ready file.',
  },
  {
    number: '02',
    icon: Palette,
    title: 'Free Artwork Proof',
    description:
      'Receive a digital mockup within 24 hours. Review, request changes, and approve — completely free of charge.',
  },
  {
    number: '03',
    icon: CheckCircle2,
    title: 'Sample Approval',
    description:
      'We produce a physical sample for your final approval before moving to mass production. Quality guaranteed.',
  },
  {
    number: '04',
    icon: Truck,
    title: 'Mass Production & Delivery',
    description:
      'Full production runs with rigorous QC. Worldwide shipping via DHL/FedEx with real-time tracking.',
  },
];

const STATS = [
  { value: '15+', label: 'Years Experience' },
  { value: '2000+', label: 'Happy Clients' },
  { value: '50+', label: 'Countries Served' },
  { value: '99%', label: 'On-time Delivery' },
];

const CERTIFICATIONS = ['ISO 9001', 'SGS Certified', 'RoHS Compliant', 'BSCI Audit'];

const ProductSkeleton = () => (
  <div className="rounded-xl border border-border bg-card overflow-hidden animate-pulse">
    <div className="aspect-[4/3] bg-muted" />
    <div className="p-6 space-y-3">
      <div className="h-5 bg-muted rounded w-3/4" />
      <div className="h-4 bg-muted rounded w-full" />
      <div className="h-4 bg-muted rounded w-2/3" />
      <div className="flex justify-between pt-2">
        <div className="h-4 bg-muted rounded w-20" />
        <div className="h-4 bg-muted rounded w-16" />
      </div>
    </div>
  </div>
);

const HomePage = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [productsRes, settingsRes] = await Promise.all([
          productsApi.getProducts(),
          siteSettingsApi.getSiteSettings(),
        ]);
        setProducts(productsRes.items.slice(0, 4));
        setSettings(settingsRes);
      } catch (err) {
        setError('Failed to load data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const heroTitle =
    settings?.heroTitle || 'Custom Badges That Make Your Brand Shine';
  const heroSubtitle =
    settings?.heroSubtitle ||
    'OEM & ODM custom badges with factory-direct pricing, low MOQ, and fast worldwide delivery.';

  return (
    <div className="bg-background">
      {/* ========== Hero Section ========== */}
      <section className="relative overflow-hidden bg-primary text-primary-foreground">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary to-[hsl(215_70%_18%)]" />
        <div className="absolute top-0 right-0 w-1/2 h-full opacity-20 bg-[radial-gradient(circle_at_top_right,_var(--accent)_0%,_transparent_60%)]" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/15 border border-accent/30 text-accent text-sm font-medium">
                <Medal className="w-4 h-4" />
                15+ Years of Badge Manufacturing Excellence
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight tracking-tight">
                {heroTitle}
              </h1>
              <p className="text-lg md:text-xl text-primary-foreground/80 max-w-xl">
                {heroSubtitle}
              </p>
              <div className="flex flex-wrap gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-accent text-accent-foreground hover:bg-accent/90 border-accent font-semibold"
                >
                  <Link to="/inquiry">
                    Get a Free Quote
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  size="lg"
                  className="border-white/40 text-white hover:bg-white/10 hover:text-white"
                >
                  <Link to="/products">View Products</Link>
                </Button>
              </div>
              <div className="flex items-center gap-6 pt-4 text-sm text-primary-foreground/70">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-accent" />
                  Free Artwork Design
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-accent" />
                  15–20 Day Delivery
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-accent" />
                  50 pcs MOQ
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl ring-1 ring-white/10">
                <Image
                  src={HERO_IMAGE_URL}
                  alt="Custom badge collection"
                  className="w-full h-auto"
                  sizes="(max-width: 1024px) 100vw, 50vw"
                  width={800}
                  height={450}
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-card text-card-foreground rounded-xl shadow-xl p-4 border border-border hidden md:flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
                  <ShieldCheck className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <div className="font-semibold">Quality Guaranteed</div>
                  <div className="text-sm text-muted-foreground">
                    100% inspection before shipping
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========== Features Section ========== */}
      <section className="py-16 md:py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-accent font-semibold text-sm tracking-wider uppercase">
              Why Choose Us
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-3 mb-4">
              Why Choose Mason Custom?
            </h2>
            <p className="text-muted-foreground text-lg">
              We combine craftsmanship, technology, and dedicated service to
              deliver custom badges your brand will be proud of.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 gap-6">
            {FEATURES.map((feature) => {
              const Icon = feature.icon;
              return (
                <Card key={feature.title} className="border-border">
                  <CardContent className="p-8">
                    <div className="w-14 h-14 rounded-xl bg-accent/15 flex items-center justify-center mb-6">
                      <Icon className="w-7 h-7 text-accent" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-3">
                      {feature.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* ========== Featured Products Section ========== */}
      <section className="py-16 md:py-24 bg-muted/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-accent font-semibold text-sm tracking-wider uppercase">
              Our Products
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-3 mb-4">
              Our Featured Products
            </h2>
            <p className="text-muted-foreground text-lg">
              Explore our most popular custom badge categories
            </p>
          </div>
          {error && (
            <div className="text-center py-8 text-destructive">{error}</div>
          )}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {loading
              ? Array.from({ length: 4 }).map((_, i) => (
                  <ProductSkeleton key={i} />
                ))
              : products.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
          </div>
          <div className="text-center mt-12">
            <Button asChild variant="default" size="lg">
              <Link to="/products">
                View All Products
                <ArrowRight className="w-4 h-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ========== Custom Process Section ========== */}
      <section className="py-16 md:py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-accent font-semibold text-sm tracking-wider uppercase">
              How It Works
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-3 mb-4">
              Simple 4-Step Process
            </h2>
            <p className="text-muted-foreground text-lg">
              From idea to delivery, we make custom badges simple and reliable
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {PROCESS_STEPS.map((step) => {
              const StepIcon = step.icon;
              return (
                <div
                  key={step.number}
                  className="relative p-6 rounded-xl border border-border bg-card hover:shadow-md transition-shadow"
                >
                  <div className="text-5xl font-bold text-accent/20 mb-4">
                    {step.number}
                  </div>
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <StepIcon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    {step.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {step.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ========== Factory / Trust Section ========== */}
      <section className="py-16 md:py-24 bg-muted/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative rounded-2xl overflow-hidden shadow-xl">
              <Image
                src={FACTORY_IMAGE_URL}
                alt="Mason Custom manufacturing facility"
                className="w-full h-auto"
                sizes="(max-width: 1024px) 100vw, 50vw"
                width={800}
                height={600}
              />
            </div>
            <div className="space-y-8">
              <div>
                <span className="text-accent font-semibold text-sm tracking-wider uppercase">
                  About Mason Custom
                </span>
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-3 mb-4">
                  Trusted by 2000+ Clients Worldwide
                </h2>
                <p className="text-muted-foreground text-lg leading-relaxed">
                  Since 2009, Mason Custom has been a trusted partner for
                  businesses, organizations, and promotional agencies around
                  the world. Our 5000 sqm factory, skilled craftsmen, and
                  stringent QC processes ensure every badge meets the highest
                  standards.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-6">
                {STATS.map((stat) => (
                  <div key={stat.label} className="space-y-1">
                    <div className="text-3xl md:text-4xl font-bold text-primary">
                      {stat.value}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {stat.label}
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex flex-wrap gap-3 pt-2">
                {CERTIFICATIONS.map((cert) => (
                  <div
                    key={cert}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card border border-border text-sm font-medium text-foreground"
                  >
                    <Award className="w-4 h-4 text-accent" />
                    {cert}
                  </div>
                ))}
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Globe2 className="w-5 h-5 text-primary" />
                <span>Shipping to 50+ countries via DHL, FedEx & UPS</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========== CTA Section ========== */}
      <section className="relative overflow-hidden bg-primary text-primary-foreground">
        <div className="absolute inset-0 bg-gradient-to-br from-primary to-[hsl(215_70%_18%)]" />
        <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[radial-gradient(circle_at_bottom_left,_var(--accent)_0%,_transparent_50%)]" />
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 text-center">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
            Ready to Create Your Custom Badges?
          </h2>
          <p className="text-lg md:text-xl text-primary-foreground/80 mb-8 max-w-2xl mx-auto">
            Get a free quote within 24 hours. No obligation, just expert advice
            and competitive pricing.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button
              asChild
              size="lg"
              className="bg-accent text-accent-foreground hover:bg-accent/90 border-accent font-semibold px-8"
            >
              <Link to="/inquiry">
                Request a Quote
                <ArrowRight className="w-4 h-4" />
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="border-white/40 text-white hover:bg-white/10 hover:text-white"
            >
              <Link to="/products">Browse Products</Link>
            </Button>
          </div>
          <p className="mt-6 text-sm text-primary-foreground/60">
            <Percent className="w-4 h-4 inline mr-1" />
            Free design service · Free sample quote · No minimum commitment
          </p>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
