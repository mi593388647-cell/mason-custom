import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Shield,
  DollarSign,
  Truck,
  Headphones,
  ArrowRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { siteSettingsApi } from '@client/src/api/index';
import type { SiteSettings } from '@shared/api.interface';
import { Image } from '@/components/ui/image';

const strengths = [
  {
    icon: Shield,
    title: 'Quality First',
    description:
      'Strict QC at every production stage, from raw materials to final inspection.',
  },
  {
    icon: DollarSign,
    title: 'Competitive Pricing',
    description:
      'Factory direct pricing with no middlemen. Premium quality at fair rates.',
  },
  {
    icon: Truck,
    title: 'Fast Delivery',
    description:
      'Efficient production lines combined with express shipping worldwide.',
  },
  {
    icon: Headphones,
    title: 'Excellent Service',
    description:
      'Dedicated account manager for every order, from quote to delivery.',
  },
];

const factoryFacts = [
  { value: '15+', label: 'Years Experience' },
  { value: '200+', label: 'Skilled Workers' },
  { value: '2000+', label: 'Happy Clients' },
  { value: '50+', label: 'Countries Served' },
  { value: '99%', label: 'On-time Delivery' },
  { value: '100%', label: 'QC Inspection' },
];

const FACTORY_IMAGE_URL =
  '/spark/app/app_17e3mfx3m35/runtime/api/v1/storage/object/bucket_aadku7kl5iujs_static/static%2Faadku7ga4twfs_ve_miaoda';

const defaultAboutText = `Founded in 2009, Mason Custom is a leading manufacturer of custom metal badges, enamel pins, and promotional products. With over 15 years of industry experience, we have built a reputation for delivering premium quality products with exceptional service.

Our 5000+ square meter factory houses more than 200 skilled workers and state-of-the-art production equipment. We serve over 2000 clients across 50+ countries, from small businesses to Fortune 500 companies.

We are ISO 9001 certified and SGS audited, ensuring every product meets the highest quality standards. Our commitment to excellence, combined with competitive pricing and fast turnaround times, makes us the trusted partner for businesses worldwide.`;

const AboutPage = () => {
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    siteSettingsApi
      .getSiteSettings()
      .then((data) => {
        if (!cancelled) setSettings(data);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const aboutText = settings?.aboutText || defaultAboutText;
  const paragraphs = aboutText.split(/\n+/).filter((p) => p.trim().length > 0);

  return (
    <div className="bg-background">
      {/* Page Header */}
      <section className="bg-primary text-primary-foreground py-16 md:py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight mb-4">
            About Mason Custom
          </h1>
          <p className="text-base md:text-lg text-white/80 max-w-2xl mx-auto">
            Your Trusted Partner in Custom Badge Manufacturing
          </p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-12 md:py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div className="relative">
              <div className="aspect-[4/3] rounded-xl overflow-hidden shadow-lg">
                <Image
                  src={FACTORY_IMAGE_URL}
                  alt="Mason Custom factory"
                  className="w-full h-full object-cover"
                  sizes="(max-width: 1024px) 100vw, 50vw"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 bg-accent text-accent-foreground px-5 py-3 rounded-lg shadow-md hidden sm:block">
                <p className="text-2xl font-bold">15+</p>
                <p className="text-xs font-medium">Years of Excellence</p>
              </div>
            </div>

            <div>
              <p className="text-accent font-semibold text-sm uppercase tracking-wider mb-3">
                Our Story
              </p>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-6 leading-tight">
                Crafting Quality Badges Since 2009
              </h2>
              {loading ? (
                <div className="space-y-4">
                  <div className="h-4 bg-muted rounded w-full animate-pulse" />
                  <div className="h-4 bg-muted rounded w-11/12 animate-pulse" />
                  <div className="h-4 bg-muted rounded w-10/12 animate-pulse" />
                </div>
              ) : (
                <div className="space-y-4 text-muted-foreground leading-relaxed">
                  {paragraphs.map((para, idx) => (
                    <p key={idx}>{para}</p>
                  ))}
                </div>
              )}

              <ul className="mt-6 space-y-3">
                {[
                  'ISO 9001 Certified Quality Management',
                  'SGS Audited Factory',
                  '5000+ sqm Production Facility',
                  '200+ Skilled Craftsmen',
                ].map((item) => (
                  <li key={item} className="flex items-center gap-3">
                    <span className="w-2 h-2 rounded-full bg-accent shrink-0" />
                    <span className="text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values / Strengths */}
      <section className="py-12 md:py-20 bg-muted/40">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-14">
            <p className="text-accent font-semibold text-sm uppercase tracking-wider mb-3">
              Why Choose Us
            </p>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground">
              Why Our Clients Trust Us
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {strengths.map((item) => {
              const Icon = item.icon;
              return (
                <Card
                  key={item.title}
                  className="hover:shadow-md transition-shadow duration-300 border-border"
                >
                  <CardContent className="pt-6">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-5">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      {item.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {item.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Factory Facts */}
      <section className="py-12 md:py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-14">
            <p className="text-accent font-semibold text-sm uppercase tracking-wider mb-3">
              By the Numbers
            </p>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground">
              Factory Facts &amp; Figures
            </h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {factoryFacts.map((fact) => (
              <div
                key={fact.label}
                className="text-center p-5 rounded-xl bg-card border border-border hover:border-accent/40 transition-colors"
              >
                <p className="text-3xl md:text-4xl font-bold text-primary mb-2">
                  {fact.value}
                </p>
                <p className="text-sm text-muted-foreground">{fact.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 md:py-20 bg-primary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-primary-foreground mb-4">
            Ready to work with a reliable badge manufacturer?
          </h2>
          <p className="text-white/70 mb-8 max-w-2xl mx-auto">
            Get in touch with our team today and receive a free quote for your
            custom badge project.
          </p>
          <Link to="/inquiry">
            <Button
              size="lg"
              className="bg-accent text-accent-foreground hover:bg-accent/90 font-semibold"
            >
              Request a Quote
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;
