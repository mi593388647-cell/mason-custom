import { useEffect, useState, useMemo } from 'react';
import type { Product } from '@shared/api.interface';
import { productsApi } from '@client/src/api/index';
import ProductCard from '@client/src/components/ProductCard';
import { logger } from '@client/src/api/index';
import { Package, Filter, AlertCircle } from 'lucide-react';

const CATEGORIES = [
  { label: 'All', value: '' },
  { label: 'Soft Enamel', value: 'soft-enamel' },
  { label: 'Die-Struck', value: 'die-struck' },
  { label: 'PVC', value: 'pvc' },
  { label: 'Hard Enamel', value: 'hard-enamel' },
];

const ProductSkeleton = () => (
  <div className="rounded-xl border border-border bg-card overflow-hidden animate-pulse">
    <div className="aspect-[4/3] bg-muted" />
    <div className="p-6 space-y-3">
      <div className="h-5 bg-muted rounded w-3/4" />
      <div className="h-4 bg-muted rounded w-full" />
      <div className="h-4 bg-muted rounded w-2/3" />
      <div className="flex justify-between pt-2">
        <div className="h-4 bg-muted rounded w-20" />
        <div className="h-4 bg-muted rounded w-16" />
      </div>
    </div>
  </div>
);

const ProductsPage = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('');

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        setError(null);
        const res = await productsApi.getProducts(
          activeCategory || undefined,
        );
        setProducts(res.items);
      } catch (err) {
        logger.error('Failed to load products', err);
        setError('Failed to load products. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, [activeCategory]);

  const filteredCount = useMemo(() => products.length, [products]);

  return (
    <div className="bg-background min-h-screen">
      {/* ========== Page Header ========== */}
      <section className="relative bg-primary text-primary-foreground overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary to-[hsl(215_70%_18%)]" />
        <div className="absolute top-0 right-0 w-1/2 h-full opacity-10 bg-[radial-gradient(circle_at_top_right,_var(--accent)_0%,_transparent_60%)]" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20 text-center">
          <span className="text-accent font-semibold text-sm tracking-wider uppercase">
            Product Catalog
          </span>
          <h1 className="text-4xl md:text-5xl font-bold mt-3 mb-4">
            Our Custom Badge Collection
          </h1>
          <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto">
            Browse our full range of custom badge types. Every badge is crafted
            to your exact specifications with premium materials and expert
            craftsmanship.
          </p>
        </div>
      </section>

      {/* ========== Category Filter ========== */}
      <section className="sticky top-0 z-20 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mr-2">
              <Filter className="w-4 h-4" />
              <span className="font-medium">Category:</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.value}
                  onClick={() => setActiveCategory(cat.value)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                    activeCategory === cat.value
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'bg-muted text-foreground hover:bg-secondary border border-transparent hover:border-border'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
            <div className="ml-auto text-sm text-muted-foreground">
              {loading
                ? 'Loading...'
                : `${filteredCount} product${filteredCount === 1 ? '' : 's'}`}
            </div>
          </div>
        </div>
      </section>

      {/* ========== Product Grid ========== */}
      <section className="py-12 md:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {error && (
            <div className="flex items-center justify-center gap-3 py-12 text-destructive bg-destructive/5 rounded-xl border border-destructive/20">
              <AlertCircle className="w-5 h-5" />
              <span>{error}</span>
            </div>
          )}

          {loading && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 6 }).map((_, i) => (
                <ProductSkeleton key={i} />
              ))}
            </div>
          )}

          {!loading && !error && products.length === 0 && (
            <div className="text-center py-20">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
                <Package className="w-8 h-8 text-muted-foreground/50" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">
                No products found
              </h3>
              <p className="text-muted-foreground max-w-sm mx-auto">
                No products found in this category. Try selecting a different
                category or check back soon for new arrivals.
              </p>
              <button
                onClick={() => setActiveCategory('')}
                className="mt-6 text-primary font-medium hover:underline"
              >
                View all products →
              </button>
            </div>
          )}

          {!loading && !error && products.length > 0 && (
            <div
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
              data-ai-section-type="card-list"
            >
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default ProductsPage;
