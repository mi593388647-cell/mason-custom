import { useEffect, useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import {
  Save,
  Plus,
  Trash2,
  Building2,
  Sparkles,
  Globe,
  HelpCircle,
} from 'lucide-react';

import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from '@client/src/components/ui/card';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@client/src/components/ui/form';
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from '@client/src/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@client/src/components/ui/alert-dialog';

import { siteSettingsApi } from '@client/src/api/index';
import type {
  SiteSettings,
  SiteSettingsUpdateRequest,
  SocialLinks,
  FaqItem,
} from '@shared/api.interface';

const socialLinksSchema = z.object({
  website: z.string(),
  facebook: z.string(),
  instagram: z.string(),
  linkedin: z.string(),
  youtube: z.string(),
});

const faqItemSchema = z.object({
  question: z.string().min(1, 'Question is required'),
  answer: z.string().min(1, 'Answer is required'),
});

const settingsSchema = z.object({
  companyName: z.string(),
  tagline: z.string(),
  aboutText: z.string(),
  contactEmail: z.string(),
  contactPhone: z.string(),
  address: z.string(),
  heroTitle: z.string(),
  heroSubtitle: z.string(),
  socialLinks: socialLinksSchema,
  faqItems: z.array(faqItemSchema),
});

type SettingsFormData = z.infer<typeof settingsSchema>;

const AdminSettingsPage = () => {
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleteIndex, setDeleteIndex] = useState<number | null>(null);

  const form = useForm<SettingsFormData>({
    resolver: zodResolver(settingsSchema),
    defaultValues: {
      companyName: '',
      tagline: '',
      aboutText: '',
      contactEmail: '',
      contactPhone: '',
      address: '',
      heroTitle: '',
      heroSubtitle: '',
      socialLinks: {
        website: '',
        facebook: '',
        instagram: '',
        linkedin: '',
        youtube: '',
      },
      faqItems: [],
    },
  });

  useEffect(() => {
    const loadSettings = async () => {
      setLoading(true);
      try {
        const settings: SiteSettings =
          await siteSettingsApi.getSiteSettings();
        form.reset({
          companyName: settings.companyName || '',
          tagline: settings.tagline || '',
          aboutText: settings.aboutText || '',
          contactEmail: settings.contactEmail || '',
          contactPhone: settings.contactPhone || '',
          address: settings.address || '',
          heroTitle: settings.heroTitle || '',
          heroSubtitle: settings.heroSubtitle || '',
          socialLinks: {
            website: settings.socialLinks?.website || '',
            facebook: settings.socialLinks?.facebook || '',
            instagram: settings.socialLinks?.instagram || '',
            linkedin: settings.socialLinks?.linkedin || '',
            youtube: settings.socialLinks?.youtube || '',
          },
          faqItems: settings.faqItems || [],
        });
      } catch (error) {
        logger.error('Failed to load settings', error);
        toast.error('Failed to load settings');
      } finally {
        setLoading(false);
      }
    };

    loadSettings();
  }, [form]);

  const onSubmit = async (data: SettingsFormData) => {
    setSaving(true);
    try {
      const socialLinks: SocialLinks = {
        website: data.socialLinks.website || undefined,
        facebook: data.socialLinks.facebook || undefined,
        instagram: data.socialLinks.instagram || undefined,
        linkedin: data.socialLinks.linkedin || undefined,
        youtube: data.socialLinks.youtube || undefined,
      };

      const updateData: SiteSettingsUpdateRequest = {
        companyName: data.companyName,
        tagline: data.tagline,
        aboutText: data.aboutText,
        contactEmail: data.contactEmail,
        contactPhone: data.contactPhone,
        address: data.address,
        heroTitle: data.heroTitle,
        heroSubtitle: data.heroSubtitle,
        socialLinks,
        faqItems: data.faqItems,
      };

      await siteSettingsApi.updateSiteSettings(updateData);
      toast.success('Settings saved successfully');
    } catch (error) {
      logger.error('Failed to save settings', error);
      toast.error('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const addFaqItem = () => {
    const currentFaq = form.getValues('faqItems') || [];
    form.setValue('faqItems', [...currentFaq, { question: '', answer: '' }]);
  };

  const removeFaqItem = (index: number) => {
    const currentFaq = form.getValues('faqItems') || [];
    form.setValue(
      'faqItems',
      currentFaq.filter((_: FaqItem, i: number) => i !== index),
    );
    setDeleteIndex(null);
  };

  const faqItems = form.watch('faqItems') || [];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-muted-foreground">Loading settings...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Site Settings</h1>
          <p className="text-sm text-muted-foreground">
            Manage company information, hero content, and site configuration
          </p>
        </div>
        <Button
          onClick={form.handleSubmit(onSubmit)}
          disabled={saving}
          className="gap-2"
        >
          <Save className="w-4 h-4" />
          Save Settings
        </Button>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <Tabs defaultValue="company" className="space-y-6">
            <TabsList>
              <TabsTrigger value="company" className="gap-2">
                <Building2 className="w-4 h-4" />
                Company
              </TabsTrigger>
              <TabsTrigger value="hero" className="gap-2">
                <Sparkles className="w-4 h-4" />
                Hero
              </TabsTrigger>
              <TabsTrigger value="social" className="gap-2">
                <Globe className="w-4 h-4" />
                Social
              </TabsTrigger>
              <TabsTrigger value="faq" className="gap-2">
                <HelpCircle className="w-4 h-4" />
                FAQ
              </TabsTrigger>
            </TabsList>

            {/* Company Information */}
            <TabsContent value="company">
              <Card>
                <CardHeader>
                  <CardTitle>Company Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="companyName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Company Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Your company name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="tagline"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tagline</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="A short tagline or slogan"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="aboutText"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>About Text</FormLabel>
                        <FormControl>
                          <Textarea
                            rows={5}
                            placeholder="Tell visitors about your company..."
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="flex flex-wrap gap-4">
                    <FormField
                      control={form.control}
                      name="contactEmail"
                      render={({ field }) => (
                        <FormItem className="flex-1 min-w-[200px]">
                          <FormLabel>Contact Email</FormLabel>
                          <FormControl>
                            <Input
                              type="email"
                              placeholder="info@company.com"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="contactPhone"
                      render={({ field }) => (
                        <FormItem className="flex-1 min-w-[200px]">
                          <FormLabel>Contact Phone</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="+1 234 567 890"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Address</FormLabel>
                        <FormControl>
                          <Textarea
                            rows={3}
                            placeholder="Full company address"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            {/* Hero Section */}
            <TabsContent value="hero">
              <Card>
                <CardHeader>
                  <CardTitle>Hero Section</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="heroTitle"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Hero Title</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Main headline for the homepage"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="heroSubtitle"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Hero Subtitle</FormLabel>
                        <FormControl>
                          <Textarea
                            rows={3}
                            placeholder="Supporting text below the title"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            {/* Social Links */}
            <TabsContent value="social">
              <Card>
                <CardHeader>
                  <CardTitle>Social Links</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="socialLinks.website"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Website</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="https://yourcompany.com"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="socialLinks.facebook"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Facebook</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="https://facebook.com/..."
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="socialLinks.instagram"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Instagram</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="https://instagram.com/..."
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="socialLinks.linkedin"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>LinkedIn</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="https://linkedin.com/..."
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="socialLinks.youtube"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>YouTube</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="https://youtube.com/..."
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* FAQ Management */}
            <TabsContent value="faq">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>FAQ Management</CardTitle>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addFaqItem}
                    className="gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    Add FAQ Item
                  </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                  {faqItems.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground text-sm">
                      No FAQ items yet. Click &quot;Add FAQ Item&quot; to
                      create one.
                    </div>
                  ) : (
                    faqItems.map((_: FaqItem, index: number) => (
                      <div
                        key={index}
                        className="border border-border rounded-lg p-4 space-y-3 relative"
                      >
                        <div className="flex items-start justify-between">
                          <div className="text-sm font-medium text-muted-foreground">
                            FAQ #{index + 1}
                          </div>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                className="text-destructive hover:text-destructive h-8 w-8 p-0"
                                onClick={() => setDeleteIndex(index)}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogTitle>
                                Delete FAQ Item
                              </AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete this FAQ item?
                                This action cannot be undone.
                              </AlertDialogDescription>
                              <AlertDialogFooter>
                                <AlertDialogCancel
                                  onClick={() => setDeleteIndex(null)}
                                >
                                  Cancel
                                </AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => removeFaqItem(index)}
                                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                        <FormField
                          control={form.control}
                          name={`faqItems.${index}.question`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Question</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="Enter the question"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name={`faqItems.${index}.answer`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Answer</FormLabel>
                              <FormControl>
                                <Textarea
                                  rows={3}
                                  placeholder="Enter the answer"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    ))
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </form>
      </Form>
    </div>
  );
};

export default AdminSettingsPage;
