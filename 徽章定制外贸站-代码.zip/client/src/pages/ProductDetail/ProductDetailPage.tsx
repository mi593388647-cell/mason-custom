import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, ShoppingCart, Mail, CheckCircle2 } from 'lucide-react';
import { productsApi } from '@client/src/api/index';
import type { Product } from '@shared/api.interface';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Skeleton } from '@client/src/components/ui/skeleton';
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from '@client/src/components/ui/breadcrumb';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Image } from '@client/src/components/ui/image';

const SPEC_LABELS: Record<string, string> = {
  material: 'Material',
  size: 'Size',
  thickness: 'Thickness',
  process: 'Process',
  plating: 'Plating',
  attachment: 'Attachment',
  colors: 'Colors',
};

export default function ProductDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeImage, setActiveImage] = useState<number>(0);

  useEffect(() => {
    if (!slug) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    productsApi
      .getProductBySlug(slug)
      .then((data: Product) => {
        if (!cancelled) {
          setProduct(data);
          setActiveImage(0);
        }
      })
      .catch((err: unknown) => {
        if (!cancelled) {
          setError('Failed to load product');
        }
        logger.error(err);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [slug]);

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <Skeleton className="h-5 w-64 mb-8" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <div className="space-y-4">
            <Skeleton className="aspect-square w-full rounded-xl" />
            <div className="flex gap-2">
              <Skeleton className="h-16 w-16 rounded-lg" />
              <Skeleton className="h-16 w-16 rounded-lg" />
              <Skeleton className="h-16 w-16 rounded-lg" />
            </div>
          </div>
          <div className="space-y-4">
            <Skeleton className="h-8 w-3/4" />
            <Skeleton className="h-5 w-1/3" />
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-10 w-1/2" />
            <Skeleton className="h-12 w-48" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 text-center">
        <div className="max-w-md mx-auto">
          <h1 className="text-3xl font-bold text-primary mb-4">
            Product Not Found
          </h1>
          <p className="text-muted-foreground mb-8">
            Sorry, the product you are looking for does not exist or has been
            removed.
          </p>
          <Link to="/products">
            <Button>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Products
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const specEntries = Object.entries(product.specifications).filter(
    ([, value]) => value && String(value).trim().length > 0,
  );

  return (
    <div className="bg-background">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
        {/* Breadcrumb */}
        <Breadcrumb className="mb-8">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link to="/">Home</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link to="/products">Products</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>{product.name}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        {/* Main Product Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 mb-16">
          {/* Images */}
          <div className="space-y-4">
            <div className="aspect-square rounded-xl overflow-hidden border border-border bg-white shadow-sm">
              {product.imageUrls[activeImage] ? (
                <Image
                  src={product.imageUrls[activeImage]}
                  alt={product.name}
                  className="w-full h-full object-contain p-4"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-secondary/50">
                  <ShoppingCart className="w-16 h-16 text-muted-foreground/40" />
                </div>
              )}
            </div>
            {product.imageUrls.length > 1 && (
              <div className="flex gap-2 flex-wrap">
                {product.imageUrls.map((url: string, idx: number) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setActiveImage(idx)}
                    className={`w-16 h-16 rounded-lg overflow-hidden border-2 transition-colors ${
                      activeImage === idx
                        ? 'border-accent'
                        : 'border-border hover:border-primary/40'
                    }`}
                  >
                    <Image
                      src={url}
                      alt={`${product.name} view ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="flex flex-col">
            <div className="inline-block px-3 py-1 rounded-full bg-accent/10 text-accent-foreground text-xs font-semibold uppercase tracking-wide w-fit mb-4">
              {product.category}
            </div>
            <h1 className="text-3xl lg:text-4xl font-bold text-primary tracking-tight mb-4">
              {product.name}
            </h1>
            <p className="text-muted-foreground leading-relaxed mb-6">
              {product.description.length > 200
                ? `${product.description.slice(0, 200)}...`
                : product.description}
            </p>

            <div className="space-y-3 mb-8 py-6 border-y border-border">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">MOQ</span>
                <span className="font-semibold text-foreground">
                  {product.moq}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Price Range</span>
                <span className="font-bold text-lg text-accent">
                  {product.priceRange}
                </span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 mb-8">
              <Link to={`/inquiry?product=${encodeURIComponent(product.name)}`}>
                <Button
                  size="lg"
                  className="w-full sm:w-auto bg-accent text-accent-foreground hover:bg-accent/90 border-accent/80 font-semibold"
                >
                  <Mail className="w-4 h-4" />
                  Request a Quote
                </Button>
              </Link>
              <Link to="/contact">
                <Button size="lg" variant="outline" className="w-full sm:w-auto">
                  Contact Us
                </Button>
              </Link>
            </div>

            <div className="flex items-start gap-2 text-sm text-muted-foreground">
              <CheckCircle2 className="w-5 h-5 text-green-600 shrink-0 mt-0.5" />
              <span>
                Free artwork proof & unlimited revisions before production.
              </span>
            </div>
          </div>
        </div>

        {/* Specifications */}
        {specEntries.length > 0 && (
          <section className="mb-16">
            <h2 className="text-2xl font-bold text-primary mb-6">
              Specifications
            </h2>
            <Card>
              <CardContent className="p-0">
                <div className="grid grid-cols-1 sm:grid-cols-2 divide-y sm:divide-y-0 sm:divide-x divide-border">
                  {specEntries.map(([key, value]) => (
                    <div
                      key={key}
                      className="flex px-6 py-4 first:sm:border-l-0"
                    >
                      <dt className="w-2/5 text-muted-foreground text-sm font-medium">
                        {SPEC_LABELS[key] || key}
                      </dt>
                      <dd className="w-3/5 text-sm font-medium text-foreground">
                        {value}
                      </dd>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </section>
        )}

        {/* Product Description */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-primary mb-6">
            Product Description
          </h2>
          <div className="prose prose-slate max-w-none text-foreground leading-relaxed">
            {product.description.split('\n').map((para: string, idx: number) =>
              para.trim() ? <p key={idx}>{para}</p> : null,
            )}
          </div>
        </section>

        {/* Bottom CTA */}
        <section
          data-ai-section-type="card-menu"
          className="rounded-2xl bg-primary p-8 lg:p-12 text-center text-primary-foreground"
        >
          <h2 className="text-2xl lg:text-3xl font-bold mb-3">
            Ready to Customize Your Badges?
          </h2>
          <p className="text-white/80 mb-6 max-w-xl mx-auto">
            Get a free, no-obligation quote tailored to your specifications. Our
            expert team will respond within 24 hours.
          </p>
          <Link to={`/inquiry?product=${encodeURIComponent(product.name)}`}>
            <Button
              size="lg"
              className="bg-accent text-accent-foreground hover:bg-accent/90 border-accent/80 font-semibold"
            >
              Get Your Free Quote
            </Button>
          </Link>
        </section>
      </div>
    </div>
  );
}
