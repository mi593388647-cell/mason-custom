import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Package,
  CheckCircle,
  Clock,
  MessageSquare,
  Plus,
  Inbox,
  ArrowRight,
  Loader2,
} from 'lucide-react';
import type { Product, Inquiry } from '@shared/api.interface';
import { productsApi, inquiriesApi } from '@client/src/api/index';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';

interface Stats {
  totalProducts: number;
  activeProducts: number;
  pendingInquiries: number;
  totalInquiries: number;
}

const AdminDashboardPage = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [productsRes, inquiriesRes] = await Promise.all([
          productsApi.getAdminProducts(),
          inquiriesApi.getInquiries(),
        ]);
        setProducts(productsRes.items);
        setInquiries(inquiriesRes.items);
      } catch (err) {
        logger.error('Failed to load dashboard data', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const stats: Stats = {
    totalProducts: products.length,
    activeProducts: products.filter((p: Product) => p.isActive).length,
    pendingInquiries: inquiries.filter((i: Inquiry) => i.status === 'pending').length,
    totalInquiries: inquiries.length,
  };

  const recentInquiries = [...inquiries]
    .sort((a: Inquiry, b: Inquiry) =>
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    )
    .slice(0, 5);

  const statCards = [
    {
      label: 'Total Products',
      value: stats.totalProducts,
      icon: Package,
      color: 'bg-primary/10 text-primary',
    },
    {
      label: 'Active Products',
      value: stats.activeProducts,
      icon: CheckCircle,
      color: 'bg-green-100 text-green-700',
    },
    {
      label: 'Pending Inquiries',
      value: stats.pendingInquiries,
      icon: Clock,
      color: 'bg-amber-100 text-amber-700',
    },
    {
      label: 'Total Inquiries',
      value: stats.totalInquiries,
      icon: MessageSquare,
      color: 'bg-accent/20 text-accent',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Welcome back, {localStorage.getItem('admin_username') || 'admin'}!
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button asChild variant="outline">
            <Link to="/admin/products">
              <Plus className="w-4 h-4" />
              Add New Product
            </Link>
          </Button>
          <Button asChild>
            <Link to="/admin/inquiries">
              <Inbox className="w-4 h-4" />
              View Pending Inquiries
            </Link>
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" data-ai-section-type="card-stat">
        {loading
          ? statCards.map((card, idx) => {
              const Icon = card.icon;
              return (
                <Card key={idx}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm text-muted-foreground">{card.label}</div>
                        <div className="h-7 mt-2 w-16 bg-muted animate-pulse rounded" />
                      </div>
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${card.color}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          : statCards.map((card, idx) => {
              const Icon = card.icon;
              return (
                <Card key={idx}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">{card.label}</p>
                        <p className="text-2xl font-bold text-foreground mt-1">{card.value}</p>
                      </div>
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${card.color}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
      </div>

      {/* Recent Inquiries + Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Inquiries */}
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between p-6 pb-4">
            <h2 className="text-lg font-semibold text-foreground">Recent Inquiries</h2>
            <Link
              to="/admin/inquiries"
              className="text-sm text-primary hover:underline flex items-center gap-1"
            >
              View All <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="px-6 pb-6">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-6 h-6 text-primary animate-spin" />
              </div>
            ) : recentInquiries.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <MessageSquare className="w-10 h-10 mx-auto mb-3 opacity-40" />
                <p>No inquiries yet</p>
              </div>
            ) : (
              <div className="overflow-hidden rounded-md border border-border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Product</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentInquiries.map((inquiry: Inquiry) => (
                      <TableRow key={inquiry.id}>
                        <TableCell className="font-medium">{inquiry.name}</TableCell>
                        <TableCell className="text-muted-foreground">{inquiry.email}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {inquiry.productType || '-'}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={inquiry.status === 'pending' ? 'secondary' : 'default'}
                          >
                            {inquiry.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {new Date(inquiry.createdAt).toLocaleDateString()}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>
        </Card>

        {/* Quick Actions */}
        <Card>
          <div className="p-6 pb-4">
            <h2 className="text-lg font-semibold text-foreground">Quick Actions</h2>
          </div>
          <div className="px-6 pb-6 space-y-3">
            <Button asChild className="w-full justify-start" variant="outline">
              <Link to="/admin/products/new">
                <Plus className="w-4 h-4" />
                Add New Product
              </Link>
            </Button>
            <Button asChild className="w-full justify-start" variant="outline">
              <Link to="/admin/inquiries">
                <Inbox className="w-4 h-4" />
                View Pending Inquiries
              </Link>
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default AdminDashboardPage;
