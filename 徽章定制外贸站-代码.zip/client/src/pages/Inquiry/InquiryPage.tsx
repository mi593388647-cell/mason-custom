import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Mail, Phone, MapPin, Clock, CheckCircle2, Send } from 'lucide-react';
import { inquiriesApi } from '@client/src/api/index';
import type { InquiryCreateRequest } from '@shared/api.interface';
import { Button } from '@client/src/components/ui/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@client/src/components/ui/card';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@client/src/components/ui/form';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { UniversalLink } from '@lark-apaas/client-toolkit/components/UniversalLink';

const inquirySchema = z.object({
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Please enter a valid email'),
  company: z.string(),
  country: z.string(),
  productType: z.string().min(1, 'Please select a product type'),
  quantity: z.string().min(1, 'Quantity is required'),
  designDescription: z.string(),
  message: z.string(),
});

type InquiryFormData = z.infer<typeof inquirySchema>;

const PRODUCT_TYPES = [
  'Soft Enamel Pins',
  'Die-Struck Pins',
  'PVC/Rubber Pins',
  'Hard Enamel Pins',
  'Challenge Coins',
  'Medals',
  'Keychains',
  'Other',
];

export default function InquiryPage() {
  const [searchParams] = useSearchParams();
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const productFromUrl = searchParams.get('product') || '';

  const form = useForm({
    resolver: zodResolver(inquirySchema),
    defaultValues: {
      name: '',
      email: '',
      company: '',
      country: '',
      productType: '',
      quantity: '50',
      designDescription: '',
      message: '',
    },
  });

  useEffect(() => {
    if (productFromUrl) {
      // Try to match an existing product type; otherwise put it in message
      const match = PRODUCT_TYPES.find(
        (p) => p.toLowerCase() === productFromUrl.toLowerCase(),
      );
      if (match) {
        form.setValue('productType', match, { shouldValidate: true });
      } else {
        form.setValue(
          'message',
          `Interested in: ${productFromUrl}`,
          { shouldValidate: false },
        );
      }
    }
  }, [productFromUrl, form]);

  const onSubmit = form.handleSubmit(async (data) => {
    const qtyNum = Number(data.quantity);
    if (!Number.isFinite(qtyNum) || qtyNum < 1) {
      form.setError('quantity', {
        message: 'Quantity must be at least 1',
      });
      return;
    }
    setSubmitting(true);
    setSubmitError(null);
    try {
      const request: InquiryCreateRequest = {
        name: data.name,
        email: data.email,
        company: data.company,
        country: data.country,
        productType: data.productType,
        quantity: qtyNum,
        designFileUrl: null,
        designFileName: null,
        message: data.designDescription
          ? `${data.message}\n\nDesign Description: ${data.designDescription}`
          : data.message,
      };
      await inquiriesApi.submitInquiry(request);
      setSubmitted(true);
      form.reset();
    } catch (err: unknown) {
      setSubmitError(
        'Something went wrong. Please try again or email us directly.',
      );
      logger.error(err);
    } finally {
      setSubmitting(false);
    }
  });

  return (
    <div className="bg-background">
      {/* Page Header */}
      <section className="bg-primary text-primary-foreground">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20 text-center">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight mb-4">
            Request a Free Quote
          </h1>
          <p className="text-lg text-white/80 max-w-2xl mx-auto">
            Fill out the form below and our sales team will get back to you
            within 24 hours.
          </p>
        </div>
      </section>

      {/* Form Section */}
      <section className="py-12 lg:py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Form - left 2/3 */}
            <div className="lg:col-span-2">
              <Card className="shadow-sm">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold text-primary">
                    {submitted ? 'Inquiry Submitted' : 'Your Details'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {submitted ? (
                    <div className="text-center py-8">
                      <div className="w-16 h-16 rounded-full bg-green-100 text-green-600 flex items-center justify-center mx-auto mb-4">
                        <CheckCircle2 className="w-8 h-8" />
                      </div>
                      <h3 className="text-xl font-semibold text-primary mb-2">
                        Thank You!
                      </h3>
                      <p className="text-muted-foreground">
                        We&apos;ve received your inquiry and will get back to
                        you within 24 hours.
                      </p>
                      <Button
                        variant="outline"
                        className="mt-6"
                        onClick={() => setSubmitted(false)}
                      >
                        Send Another Inquiry
                      </Button>
                    </div>
                  ) : (
                    <Form {...form}>
                      <form
                        onSubmit={onSubmit}
                        className="space-y-5"
                      >
                        <div className="flex flex-wrap gap-4">
                          <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem className="flex-1 min-w-[180px]">
                                <FormLabel>
                                  Name <span className="text-destructive">*</span>
                                </FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="Your full name"
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem className="flex-1 min-w-[180px]">
                                <FormLabel>
                                  Email <span className="text-destructive">*</span>
                                </FormLabel>
                                <FormControl>
                                  <Input
                                    type="email"
                                    placeholder="you@company.com"
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="flex flex-wrap gap-4">
                          <FormField
                            control={form.control}
                            name="company"
                            render={({ field }) => (
                              <FormItem className="flex-1 min-w-[180px]">
                                <FormLabel>Company</FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="Your company name"
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="country"
                            render={({ field }) => (
                              <FormItem className="flex-1 min-w-[180px]">
                                <FormLabel>Country</FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="Your country"
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="flex flex-wrap gap-4">
                          <FormField
                            control={form.control}
                            name="productType"
                            render={({ field }) => (
                              <FormItem className="flex-1 min-w-[200px]">
                                <FormLabel>
                                  Product Type{' '}
                                  <span className="text-destructive">*</span>
                                </FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                  value={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger className="w-full">
                                      <SelectValue placeholder="Select a product type" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    {PRODUCT_TYPES.map((type) => (
                                      <SelectItem key={type} value={type}>
                                        {type}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="quantity"
                            render={({ field }) => (
                              <FormItem className="flex-1 min-w-[150px]">
                                <FormLabel>
                                  Quantity{' '}
                                  <span className="text-destructive">*</span>
                                </FormLabel>
                                <FormControl>
                                  <Input
                                    type="number"
                                    min={1}
                                    placeholder="e.g. 500"
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={form.control}
                          name="designDescription"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Design Description</FormLabel>
                              <FormControl>
                                <Textarea
                                  rows={3}
                                  placeholder="Describe your design, colors, size requirements, etc."
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="message"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Special Requirements</FormLabel>
                              <FormControl>
                                <Textarea
                                  rows={4}
                                  placeholder="Any additional details or questions"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {submitError && (
                          <div className="p-3 rounded-md bg-destructive/10 text-destructive text-sm">
                            {submitError}
                          </div>
                        )}

                        <Button
                          type="submit"
                          size="lg"
                          disabled={submitting}
                          className="w-full sm:w-auto bg-accent text-accent-foreground hover:bg-accent/90 border-accent/80 font-semibold"
                        >
                          <Send className="w-4 h-4" />
                          {submitting ? 'Submitting...' : 'Submit Inquiry'}
                        </Button>
                      </form>
                    </Form>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Contact Info - right 1/3 */}
            <div className="space-y-6">
              <Card className="shadow-sm">
                <CardHeader>
                  <CardTitle className="text-xl font-bold text-primary">
                    Contact Us Directly
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-5">
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-lg bg-accent/10 text-accent flex items-center justify-center shrink-0">
                      <Mail className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-medium text-foreground">
                        Email
                      </div>
                      <UniversalLink
                        to="mailto:Mason_Sn.co@outlook.com"
                        className="text-sm text-muted-foreground hover:text-accent transition-colors"
                      >
                        Mason_Sn.co@outlook.com
                      </UniversalLink>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-lg bg-accent/10 text-accent flex items-center justify-center shrink-0">
                      <Phone className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-medium text-foreground">
                        Phone / WhatsApp
                      </div>
                      <UniversalLink
                        to="tel:+8613800000000"
                        className="text-sm text-muted-foreground hover:text-accent transition-colors"
                      >
                        +86-138-0000-0000
                      </UniversalLink>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-lg bg-accent/10 text-accent flex items-center justify-center shrink-0">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-medium text-foreground">
                        Address
                      </div>
                      <p className="text-sm text-muted-foreground">
                        No. 88 Industrial Road,
                        <br />
                        Shenzhen, China
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-lg bg-accent/10 text-accent flex items-center justify-center shrink-0">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-medium text-foreground">
                        Working Hours
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Mon - Sat, 9:00 - 18:00
                        <br />
                        GMT+8
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-sm bg-accent/5 border-accent/20">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <span className="font-semibold text-foreground">
                      24-Hour Response
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Our sales team responds to every inquiry within 24 business
                    hours with a detailed quote.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
