import React from 'react';
import { Route, Routes } from 'react-router-dom';

import Layout from './components/Layout';
import AdminLayout from './components/AdminLayout';
import NotFound from './pages/NotFound/NotFound';
import HomePage from './pages/Home/HomePage';
import ProductsPage from './pages/Products/ProductsPage';
import ProductDetailPage from './pages/ProductDetail/ProductDetailPage';
import CustomProcessPage from './pages/CustomProcess/CustomProcessPage';
import InquiryPage from './pages/Inquiry/InquiryPage';
import AboutPage from './pages/About/AboutPage';
import FaqPage from './pages/Faq/FaqPage';
import ContactPage from './pages/Contact/ContactPage';
import AdminLoginPage from './pages/AdminLogin/AdminLoginPage';
import AdminDashboardPage from './pages/AdminDashboard/AdminDashboardPage';
import AdminProductsPage from './pages/AdminProducts/AdminProductsPage';
import AdminProductEditPage from './pages/AdminProductEdit/AdminProductEditPage';
import AdminInquiriesPage from './pages/AdminInquiries/AdminInquiriesPage';
import AdminSettingsPage from './pages/AdminSettings/AdminSettingsPage';

const RoutesComponent = () => {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<HomePage />} />
        <Route path="products" element={<ProductsPage />} />
        <Route path="products/:slug" element={<ProductDetailPage />} />
        <Route path="custom-process" element={<CustomProcessPage />} />
        <Route path="inquiry" element={<InquiryPage />} />
        <Route path="about" element={<AboutPage />} />
        <Route path="faq" element={<FaqPage />} />
        <Route path="contact" element={<ContactPage />} />
      </Route>
      <Route path="admin/login" element={<AdminLoginPage />} />
      <Route path="admin" element={<AdminLayout />}>
        <Route index element={<AdminDashboardPage />} />
        <Route path="products" element={<AdminProductsPage />} />
        <Route path="products/new" element={<AdminProductEditPage />} />
        <Route path="products/:id/edit" element={<AdminProductEditPage />} />
        <Route path="inquiries" element={<AdminInquiriesPage />} />
        <Route path="settings" element={<AdminSettingsPage />} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default RoutesComponent;
