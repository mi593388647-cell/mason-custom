import { Link } from 'react-router-dom';
import { Award } from 'lucide-react';
import type { Product } from '@shared/api.interface';
import { Card, CardContent } from '@client/src/components/ui/card';
import Image from '@client/src/components/ui/image';

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const firstImage = product.imageUrls?.[0];

  return (
    <Link to={`/products/${product.slug}`} className="block group">
      <Card className="h-full overflow-hidden transition-all duration-300 group-hover:-translate-y-1 group-hover:shadow-lg border-border">
        <div className="relative aspect-[4/3] overflow-hidden bg-muted">
          {firstImage ? (
            <Image
              src={firstImage}
              alt={product.name}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-secondary">
              <Award className="w-12 h-12 text-muted-foreground opacity-30" />
            </div>
          )}
          {product.category && (
            <span className="absolute top-3 left-3 px-3 py-1 text-xs font-medium bg-background/90 text-foreground rounded-full backdrop-blur-sm">
              {product.category}
            </span>
          )}
        </div>
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-foreground mb-2 line-clamp-1 group-hover:text-primary transition-colors">
            {product.name}
          </h3>
          <p className="text-sm text-muted-foreground mb-4 line-clamp-2 min-h-[2.5rem]">
            {product.description}
          </p>
          <div className="flex items-center justify-between text-sm">
            <div className="text-muted-foreground">
              <span className="font-medium text-foreground">MOQ:</span>{' '}
              {product.moq}
            </div>
            <div className="text-accent font-semibold">{product.priceRange}</div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
};

export default ProductCard;
