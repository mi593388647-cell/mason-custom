import { Outlet, Link, NavLink } from 'react-router-dom';
import {
  Award,
  Mail,
  Phone,
  MapPin,
  Menu,
  X,
  Facebook,
  Instagram,
  Linkedin,
  Youtube,
} from 'lucide-react';
import { useState } from 'react';
import { Button } from '@client/src/components/ui/button';
import { UniversalLink } from '@lark-apaas/client-toolkit/components/UniversalLink';

const navLinks = [
  { to: '/', label: 'Home', end: true },
  { to: '/products', label: 'Products' },
  { to: '/custom-process', label: 'Custom Process' },
  { to: '/about', label: 'About Us' },
  { to: '/faq', label: 'FAQ' },
  { to: '/contact', label: 'Contact' },
];

const productCategories = [
  'Enamel Pins',
  'Soft Enamel Badges',
  'Hard Enamel Badges',
  'Printed Badges',
  'Medals & Coins',
  'Keychains',
];

const quickLinks = [
  { to: '/products', label: 'Products' },
  { to: '/custom-process', label: 'Custom Process' },
  { to: '/about', label: 'About Us' },
  { to: '/faq', label: 'FAQ' },
  { to: '/contact', label: 'Contact' },
  { to: '/inquiry', label: 'Get a Quote' },
];

const Layout = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      {/* Navbar */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border shadow-sm">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2">
              <Award className="w-7 h-7 text-accent" />
              <span className="text-xl font-bold text-primary tracking-tight">
                 Mason Custom
              </span>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-1">
              {navLinks.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.end}
                  className={({ isActive }) =>
                    `px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                      isActive
                        ? 'text-primary'
                        : 'text-muted-foreground hover:text-foreground'
                    }`
                  }
                >
                  {link.label}
                </NavLink>
              ))}
            </nav>

            {/* CTA + Mobile Menu */}
            <div className="flex items-center gap-3">
              <Link to="/inquiry" className="hidden sm:block">
                <Button className="bg-accent text-accent-foreground hover:bg-accent/90 border-accent/80 font-semibold">
                  Get a Quote
                </Button>
              </Link>
              <button
                className="lg:hidden p-2 text-muted-foreground hover:text-foreground"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label="Toggle menu"
              >
                {mobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-border bg-background">
            <nav className="px-4 py-3 space-y-1">
              {navLinks.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.end}
                  onClick={() => setMobileMenuOpen(false)}
                  className={({ isActive }) =>
                    `block px-3 py-2 rounded-md text-sm font-medium ${
                      isActive
                        ? 'bg-secondary text-foreground'
                        : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
                    }`
                  }
                >
                  {link.label}
                </NavLink>
              ))}
              <Link
                to="/inquiry"
                onClick={() => setMobileMenuOpen(false)}
                className="block mt-3"
              >
                <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90 border-accent/80 font-semibold">
                  Get a Quote
                </Button>
              </Link>
            </nav>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
            {/* Company Info */}
            <div className="lg:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <Award className="w-7 h-7 text-accent" />
                <span className="text-xl font-bold">Mason Custom</span>
              </div>
              <p className="text-sm text-white/70 leading-relaxed mb-4">
                Professional custom badge and pin manufacturer. Delivering
                premium quality products to businesses worldwide since 2008.
              </p>
              <div className="flex items-center gap-3">
                <UniversalLink
                  to="#"
                  className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-accent hover:text-accent-foreground transition-colors"
                  aria-label="Facebook"
                >
                  <Facebook className="w-4 h-4" />
                </UniversalLink>
                <UniversalLink
                  to="#"
                  className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-accent hover:text-accent-foreground transition-colors"
                  aria-label="Instagram"
                >
                  <Instagram className="w-4 h-4" />
                </UniversalLink>
                <UniversalLink
                  to="#"
                  className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-accent hover:text-accent-foreground transition-colors"
                  aria-label="LinkedIn"
                >
                  <Linkedin className="w-4 h-4" />
                </UniversalLink>
                <UniversalLink
                  to="#"
                  className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-accent hover:text-accent-foreground transition-colors"
                  aria-label="Youtube"
                >
                  <Youtube className="w-4 h-4" />
                </UniversalLink>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wider text-white mb-4">
                Quick Links
              </h3>
              <ul className="space-y-2.5">
                {quickLinks.map((link) => (
                  <li key={link.to}>
                    <Link
                      to={link.to}
                      className="text-sm text-white/70 hover:text-accent transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Product Categories */}
            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wider text-white mb-4">
                Product Categories
              </h3>
              <ul className="space-y-2.5">
                {productCategories.map((cat) => (
                  <li key={cat}>
                    <Link
                      to={`/products?category=${encodeURIComponent(cat)}`}
                      className="text-sm text-white/70 hover:text-accent transition-colors"
                    >
                      {cat}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wider text-white mb-4">
                Contact Us
              </h3>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <Mail className="w-4 h-4 text-accent mt-0.5 shrink-0" />
                  <UniversalLink
                    to="mailto:Mason_Sn.co@outlook.com"
                    className="text-sm text-white/70 hover:text-accent transition-colors"
                  >
                    Mason_Sn.co@outlook.com
                  </UniversalLink>
                </li>
                <li className="flex items-start gap-3">
                  <Phone className="w-4 h-4 text-accent mt-0.5 shrink-0" />
                  <UniversalLink
                    to="tel:+8612345678900"
                    className="text-sm text-white/70 hover:text-accent transition-colors"
                  >
                    +86 123 4567 8900
                  </UniversalLink>
                </li>
                <li className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-accent mt-0.5 shrink-0" />
                  <span className="text-sm text-white/70">
                    No. 88 Industrial Road,
                    <br />
                    Shenzhen, China
                  </span>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom bar */}
          <div className="mt-10 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-white/50">
              © {new Date().getFullYear()} Mason Custom. All rights reserved.
            </p>
            <div className="flex items-center gap-6 text-sm text-white/50">
              <UniversalLink to="#" className="hover:text-white/70 transition-colors">
                Privacy Policy
              </UniversalLink>
              <UniversalLink to="#" className="hover:text-white/70 transition-colors">
                Terms of Service
              </UniversalLink>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
