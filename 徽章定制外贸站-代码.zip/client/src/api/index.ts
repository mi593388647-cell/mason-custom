import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';

export * as productsApi from './products';
export * as inquiriesApi from './inquiries';
export * as siteSettingsApi from './site-settings';
export * as adminAuthApi from './admin-auth';

export { axiosForBackend, logger };
