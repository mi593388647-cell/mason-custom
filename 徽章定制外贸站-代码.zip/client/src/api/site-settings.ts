import type {
  SiteSettings,
  SiteSettingsUpdateRequest,
} from '@shared/api.interface';
import { axiosForBackend, logger } from './index';

export async function getSiteSettings(): Promise<SiteSettings> {
  try {
    const { data } = await axiosForBackend.get<SiteSettings>('/api/site-settings');
    return data;
  } catch (error) {
    logger.error('Failed to fetch site settings', error);
    throw error;
  }
}

export async function updateSiteSettings(
  data: SiteSettingsUpdateRequest,
): Promise<SiteSettings> {
  try {
    const response = await axiosForBackend.patch<SiteSettings>(
      '/api/site-settings',
      data,
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('admin_token')}`,
        },
      },
    );
    return response.data;
  } catch (error) {
    logger.error('Failed to update site settings', error);
    throw error;
  }
}
