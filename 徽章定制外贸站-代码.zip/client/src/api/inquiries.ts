import type {
  Inquiry,
  InquiryListResponse,
  InquiryCreateRequest,
} from '@shared/api.interface';
import { axiosForBackend, logger } from './index';

export async function submitInquiry(
  data: InquiryCreateRequest,
): Promise<{ id: string }> {
  try {
    const response = await axiosForBackend.post<{ id: string }>(
      '/api/inquiries',
      data,
    );
    return response.data;
  } catch (error) {
    logger.error('Failed to submit inquiry', error);
    throw error;
  }
}

export async function getInquiries(status?: string): Promise<InquiryListResponse> {
  try {
    const { data } = await axiosForBackend.get<InquiryListResponse>(
      '/api/inquiries',
      {
        params: status ? { status } : undefined,
        headers: {
          Authorization: `Bearer ${localStorage.getItem('admin_token')}`,
        },
      },
    );
    return data;
  } catch (error) {
    logger.error('Failed to fetch inquiries', error);
    throw error;
  }
}

export async function getInquiry(id: string): Promise<Inquiry> {
  try {
    const { data } = await axiosForBackend.get<Inquiry>(`/api/inquiries/${id}`, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('admin_token')}`,
      },
    });
    return data;
  } catch (error) {
    logger.error(`Failed to fetch inquiry: ${id}`, error);
    throw error;
  }
}

export async function updateInquiryStatus(
  id: string,
  status: string,
): Promise<Inquiry> {
  try {
    const { data } = await axiosForBackend.patch<Inquiry>(
      `/api/inquiries/${id}/status`,
      { status },
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('admin_token')}`,
        },
      },
    );
    return data;
  } catch (error) {
    logger.error(`Failed to update inquiry status: ${id}`, error);
    throw error;
  }
}
