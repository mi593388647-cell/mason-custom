import type {
  Product,
  ProductListResponse,
  ProductCreateRequest,
  ProductUpdateRequest,
} from '@shared/api.interface';
import { axiosForBackend, logger } from './index';

export async function getProducts(category?: string): Promise<ProductListResponse> {
  try {
    const { data } = await axiosForBackend.get<ProductListResponse>('/api/products', {
      params: category ? { category } : undefined,
    });
    return data;
  } catch (error) {
    logger.error('Failed to fetch products', error);
    throw error;
  }
}

export async function getProductBySlug(slug: string): Promise<Product> {
  try {
    const { data } = await axiosForBackend.get<Product>(`/api/products/${slug}`);
    return data;
  } catch (error) {
    logger.error(`Failed to fetch product: ${slug}`, error);
    throw error;
  }
}

export async function getAdminProducts(): Promise<ProductListResponse> {
  try {
    const { data } = await axiosForBackend.get<ProductListResponse>(
      '/api/products/admin/list',
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('admin_token')}`,
        },
      },
    );
    return data;
  } catch (error) {
    logger.error('Failed to fetch admin products', error);
    throw error;
  }
}

export async function createProduct(data: ProductCreateRequest): Promise<Product> {
  try {
    const response = await axiosForBackend.post<Product>('/api/products', data, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('admin_token')}`,
      },
    });
    return response.data;
  } catch (error) {
    logger.error('Failed to create product', error);
    throw error;
  }
}

export async function updateProduct(
  id: string,
  data: ProductUpdateRequest,
): Promise<Product> {
  try {
    const response = await axiosForBackend.patch<Product>(
      `/api/products/${id}`,
      data,
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('admin_token')}`,
        },
      },
    );
    return response.data;
  } catch (error) {
    logger.error(`Failed to update product: ${id}`, error);
    throw error;
  }
}

export async function deleteProduct(id: string): Promise<{ success: true }> {
  try {
    const { data } = await axiosForBackend.delete<{ success: true }>(
      `/api/products/${id}`,
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('admin_token')}`,
        },
      },
    );
    return data;
  } catch (error) {
    logger.error(`Failed to delete product: ${id}`, error);
    throw error;
  }
}
