import type { AdminLoginResponse } from '@shared/api.interface';
import { axiosForBackend, logger } from './index';

export async function adminLogin(
  username: string,
  password: string,
): Promise<AdminLoginResponse> {
  try {
    const { data } = await axiosForBackend.post<AdminLoginResponse>(
      '/api/admin-auth/login',
      { username, password },
    );
    return data;
  } catch (error) {
    logger.error('Admin login failed', error);
    throw error;
  }
}
